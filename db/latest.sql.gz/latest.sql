--
-- PostgreSQL database dump
--

\restrict JdoioBbiJklHmJCfVQOclUJTbeyyMhdXBo8c5VgUuJwT9KlZ2NobDucq7UQg1L8

-- Dumped from database version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: drizzle; Type: SCHEMA; Schema: -; Owner: coach
--

CREATE SCHEMA drizzle;


ALTER SCHEMA drizzle OWNER TO coach;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: __drizzle_migrations; Type: TABLE; Schema: drizzle; Owner: coach
--

CREATE TABLE drizzle.__drizzle_migrations (
    id integer NOT NULL,
    hash text NOT NULL,
    created_at bigint
);


ALTER TABLE drizzle.__drizzle_migrations OWNER TO coach;

--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE; Schema: drizzle; Owner: coach
--

CREATE SEQUENCE drizzle.__drizzle_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE drizzle.__drizzle_migrations_id_seq OWNER TO coach;

--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: drizzle; Owner: coach
--

ALTER SEQUENCE drizzle.__drizzle_migrations_id_seq OWNED BY drizzle.__drizzle_migrations.id;


--
-- Name: accounts; Type: TABLE; Schema: public; Owner: coach
--

CREATE TABLE public.accounts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    type text NOT NULL,
    provider text NOT NULL,
    provider_account_id text NOT NULL,
    refresh_token text,
    access_token text,
    expires_at integer,
    token_type text,
    scope text,
    id_token text,
    session_state text
);


ALTER TABLE public.accounts OWNER TO coach;

--
-- Name: ai_analyses; Type: TABLE; Schema: public; Owner: coach
--

CREATE TABLE public.ai_analyses (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    session_id uuid,
    session_date date NOT NULL,
    session_summary text,
    exercise_decisions jsonb,
    overall_recommendation text,
    analyzed_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ai_analyses OWNER TO coach;

--
-- Name: ai_briefings; Type: TABLE; Schema: public; Owner: coach
--

CREATE TABLE public.ai_briefings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    session_id uuid,
    session_date date NOT NULL,
    note text NOT NULL,
    generated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ai_briefings OWNER TO coach;

--
-- Name: auth_sessions; Type: TABLE; Schema: public; Owner: coach
--

CREATE TABLE public.auth_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    session_token text NOT NULL,
    user_id uuid NOT NULL,
    expires timestamp without time zone NOT NULL
);


ALTER TABLE public.auth_sessions OWNER TO coach;

--
-- Name: body_weight_log; Type: TABLE; Schema: public; Owner: coach
--

CREATE TABLE public.body_weight_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    date date NOT NULL,
    kg numeric(5,1) NOT NULL
);


ALTER TABLE public.body_weight_log OWNER TO coach;

--
-- Name: exercise_catalog; Type: TABLE; Schema: public; Owner: coach
--

CREATE TABLE public.exercise_catalog (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    name text NOT NULL,
    notes text DEFAULT ''::text NOT NULL,
    default_sets integer,
    default_reps text,
    default_weight numeric(6,2),
    muscle_groups jsonb,
    equipment text,
    created_by_ai boolean DEFAULT false NOT NULL
);


ALTER TABLE public.exercise_catalog OWNER TO coach;

--
-- Name: gym_exercises; Type: TABLE; Schema: public; Owner: coach
--

CREATE TABLE public.gym_exercises (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    session_id uuid NOT NULL,
    name text NOT NULL,
    target_sets integer,
    target_reps text,
    notes text DEFAULT ''::text NOT NULL,
    order_idx integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.gym_exercises OWNER TO coach;

--
-- Name: gym_sessions; Type: TABLE; Schema: public; Owner: coach
--

CREATE TABLE public.gym_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    date date NOT NULL,
    name text NOT NULL,
    session_type text,
    started_at timestamp without time zone,
    finished_at timestamp without time zone,
    notes text DEFAULT ''::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.gym_sessions OWNER TO coach;

--
-- Name: gym_sets; Type: TABLE; Schema: public; Owner: coach
--

CREATE TABLE public.gym_sets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    exercise_id uuid NOT NULL,
    set_no integer NOT NULL,
    reps integer,
    weight numeric(6,2),
    rpe numeric(3,1),
    done boolean DEFAULT false NOT NULL,
    rir integer
);


ALTER TABLE public.gym_sets OWNER TO coach;

--
-- Name: mesocycles; Type: TABLE; Schema: public; Owner: coach
--

CREATE TABLE public.mesocycles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    name text NOT NULL,
    goal text DEFAULT ''::text NOT NULL,
    phase text DEFAULT ''::text NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    weekly_structure jsonb,
    exercises jsonb NOT NULL,
    rules jsonb,
    warmup_protocol jsonb,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.mesocycles OWNER TO coach;

--
-- Name: personal_records; Type: TABLE; Schema: public; Owner: coach
--

CREATE TABLE public.personal_records (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    exercise_name text NOT NULL,
    weight numeric(6,2),
    reps integer,
    e1rm numeric(6,2),
    achieved_at date NOT NULL
);


ALTER TABLE public.personal_records OWNER TO coach;

--
-- Name: session_templates; Type: TABLE; Schema: public; Owner: coach
--

CREATE TABLE public.session_templates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    name text NOT NULL,
    exercises jsonb DEFAULT '[]'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    mesocycle_id uuid,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.session_templates OWNER TO coach;

--
-- Name: user_settings; Type: TABLE; Schema: public; Owner: coach
--

CREATE TABLE public.user_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    situation_prompt text DEFAULT ''::text NOT NULL,
    rest_timer_default integer DEFAULT 120 NOT NULL,
    ai_enabled boolean DEFAULT true NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    ai_mesocycle_enabled boolean DEFAULT true NOT NULL,
    ai_session_analysis_enabled boolean DEFAULT true NOT NULL,
    ai_briefing_enabled boolean DEFAULT true NOT NULL,
    ai_substitution_enabled boolean DEFAULT true NOT NULL,
    ai_deload_detection_enabled boolean DEFAULT true NOT NULL
);


ALTER TABLE public.user_settings OWNER TO coach;

--
-- Name: users; Type: TABLE; Schema: public; Owner: coach
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email text NOT NULL,
    name text,
    password_hash text,
    email_verified timestamp without time zone,
    image text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_admin boolean DEFAULT false NOT NULL
);


ALTER TABLE public.users OWNER TO coach;

--
-- Name: verification_tokens; Type: TABLE; Schema: public; Owner: coach
--

CREATE TABLE public.verification_tokens (
    identifier text NOT NULL,
    token text NOT NULL,
    expires timestamp without time zone NOT NULL
);


ALTER TABLE public.verification_tokens OWNER TO coach;

--
-- Name: weekly_ai_summaries; Type: TABLE; Schema: public; Owner: coach
--

CREATE TABLE public.weekly_ai_summaries (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    week_start text NOT NULL,
    summary text NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.weekly_ai_summaries OWNER TO coach;

--
-- Name: weight_overrides; Type: TABLE; Schema: public; Owner: coach
--

CREATE TABLE public.weight_overrides (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    exercise_name text NOT NULL,
    next_weight_kg numeric(6,2) NOT NULL,
    reason text DEFAULT ''::text NOT NULL,
    from_session_date date,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.weight_overrides OWNER TO coach;

--
-- Name: __drizzle_migrations id; Type: DEFAULT; Schema: drizzle; Owner: coach
--

ALTER TABLE ONLY drizzle.__drizzle_migrations ALTER COLUMN id SET DEFAULT nextval('drizzle.__drizzle_migrations_id_seq'::regclass);


--
-- Data for Name: __drizzle_migrations; Type: TABLE DATA; Schema: drizzle; Owner: coach
--

COPY drizzle.__drizzle_migrations (id, hash, created_at) FROM stdin;
1	2e1babe1d0c0207643f251357fc99c72b2bbcc74f20f2bfc28fca5d54a2f3f67	1783666154480
2	6521f36ad189814a3221e8741b52f5cc46d6d34d2ac06f7d52babbecba6546bc	1783667582449
\.


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: coach
--

COPY public.accounts (id, user_id, type, provider, provider_account_id, refresh_token, access_token, expires_at, token_type, scope, id_token, session_state) FROM stdin;
\.


--
-- Data for Name: ai_analyses; Type: TABLE DATA; Schema: public; Owner: coach
--

COPY public.ai_analyses (id, user_id, session_id, session_date, session_summary, exercise_decisions, overall_recommendation, analyzed_at) FROM stdin;
4bdbab7d-9b72-4eb9-a4f9-05b2fefc4185	1add2a3d-727f-4607-aaad-759861f62394	\N	2026-07-07	The session showed good consistency across most exercises, with some variations in rep counts. RPEs were not provided, which makes precise adjustments challenging, so decisions are based on rep performance relative to typical targets.	[{"reason": "Performance was consistent with previous sessions at this weight, but without RPE, it's safer to maintain. The target for DB Bench Press (from mesocycle) is 3x8, so 3x6,5,6 is not yet hitting the target.", "decision": "maintain", "exercise_name": "Bench Press Dumbbells", "next_weight_kg": 32, "actual_performance": "3x6, 5, 6 @32kg"}, {"reason": "Consistent performance at 3x8 reps. Since the mesocycle specifies 'Weighted Pull-ups' with a start weight, this bodyweight version is likely a different exercise or a lead-in. Maintaining bodyweight for now.", "decision": "maintain", "exercise_name": "Pull-ups (Bodyweight)", "next_weight_kg": null, "actual_performance": "3x8 @0kg"}, {"reason": "Consistent performance for 2 sets. Without a target or RPE, maintaining is the conservative approach.", "decision": "maintain", "exercise_name": "Lateral Raises Machine", "next_weight_kg": 30, "actual_performance": "2x10 @30kg"}, {"reason": "Good performance with 12 and 11 reps. The mesocycle has 'DB Overhead Press (Standing)' as a different exercise. Maintaining current weight due to lack of RPE and specific target for this machine exercise.", "decision": "maintain", "exercise_name": "Shoulder Press Machine", "next_weight_kg": 20, "actual_performance": "2x12, 11 @20kg"}, {"reason": "Consistent performance across all sets. Without a target or RPE, maintaining is appropriate.", "decision": "maintain", "exercise_name": "Triceps Overhead", "next_weight_kg": 30, "actual_performance": "3x10 @30kg"}, {"reason": "Consistent performance for 2 sets. Without a target or RPE, maintaining is the conservative approach.", "decision": "maintain", "exercise_name": "Butterfly", "next_weight_kg": 57, "actual_performance": "2x10 @57kg"}]	Focus on hitting target reps for all exercises in the next session, and consider adding RPE to future logs for more precise adjustments.	2026-07-09 13:36:01.057
f0a91375-13b7-438e-8088-ec54be294ef8	1add2a3d-727f-4607-aaad-759861f62394	\N	2026-07-09	The session was incomplete, with only one set performed for each exercise. This makes it difficult to assess performance accurately and apply progression rules effectively.	[{"reason": "Only one set completed, insufficient data to progress. Maintain weight to attempt full target next session.", "decision": "maintain", "exercise_name": "DB Bench Press", "next_weight_kg": 32, "actual_performance": "1x8 @32kg"}]	Focus on completing all prescribed sets and reps for each exercise in the next session to allow for proper progression assessment.	2026-07-09 13:52:07.221
84fe769d-b934-4590-8b99-bcecf84632e4	1add2a3d-727f-4607-aaad-759861f62394	\N	2026-07-10	The athlete did not complete any sets in this session. Therefore, no performance data is available for analysis or weight adjustments. The plan for the next session will be based on the mesocycle and recent historical data.	[]	The athlete needs to complete the planned sets and reps with RPEs to allow for proper analysis and progression.	2026-07-10 12:02:52.886936
ae18e5e0-58fa-48ce-9322-3a7212faadf1	1add2a3d-727f-4607-aaad-759861f62394	\N	2026-07-26	The athlete completed a full Gym Session 1 with good performance on most exercises. Back Squat showed good RIR, while DB Bench Press and Pull-ups were challenging, with some sets falling short of the target reps. Split Squats were completed with high effort. Bodyweight and core exercises were performed as targeted.	[{"reason": "Bodyweight exercise, performed as targeted. Focus on explosive movement.", "decision": "maintain", "exercise_name": "Coutermovement Jump", "next_weight_kg": null, "actual_performance": "3x3 at bodyweight."}, {"reason": "First set RIR of 3 indicates good room for progression. Assuming the second set was also manageable, a small weight increase is appropriate.", "decision": "progress", "exercise_name": "Back Squat", "next_weight_kg": 82.5, "actual_performance": "2x5 at 80kg with RIR 3 and then an unspecified RIR for the second set."}, {"reason": "Athlete failed to hit target reps on all sets and reported RIR 0, indicating maximal effort. Maintain weight to consolidate strength at this load before progressing.", "decision": "maintain", "exercise_name": "DB Bench Press", "next_weight_kg": 32, "actual_performance": "Set 1: 5 reps at 32kg (RIR 0). Set 2: 5 reps at 32kg (RIR 0). Set 3: 4 reps at 32kg (RIR 0). Target was 3x6."}, {"reason": "Athlete missed one rep on the second set. Maintain bodyweight to ensure consistent performance across all sets before considering weighted pull-ups or increased reps.", "decision": "maintain", "exercise_name": "Pull-ups (Bodyweight)", "next_weight_kg": null, "actual_performance": "Set 1: 8 reps. Set 2: 7 reps. Set 3: 8 reps. Target was 3x8."}, {"reason": "All sets completed for target reps, though RIR decreased significantly towards the end, indicating high effort. A small increase is warranted given the successful completion.", "decision": "progress", "exercise_name": "Split Squat", "next_weight_kg": 17.5, "actual_performance": "Set 1: 8 reps at 16kg (RIR 2). Set 2: 8 reps at 16kg (RIR 1). Set 3: 8 reps at 16kg (RIR 0). Target was 3x8."}, {"reason": "Bodyweight exercise, performed as targeted. Continue to focus on quality and time under tension.", "decision": "maintain", "exercise_name": "Copenhagen Plank", "next_weight_kg": null, "actual_performance": "3x20 reps (likely seconds, given typical plank duration)."}, {"reason": "Bodyweight/resistance band exercise, performed as targeted. Focus on anti-rotation and core stability.", "decision": "maintain", "exercise_name": "Pallof Press 2 sec Hold", "next_weight_kg": null, "actual_performance": "3x8 reps."}, {"reason": "Bodyweight exercise, performed as targeted. Continue to focus on controlled movement for ankle health.", "decision": "maintain", "exercise_name": "Tibialis Raises", "next_weight_kg": null, "actual_performance": "2x15 reps."}]	The athlete showed good effort and generally met or came close to targets, indicating a readiness for slight progression on some exercises while maintaining others to solidify strength.	2026-07-26 08:34:34.801449
643ed977-b6a0-4488-a149-c87112a2d318	1add2a3d-727f-4607-aaad-759861f62394	\N	2026-08-04	The athlete performed well on most exercises, completing all sets and reps for Countermovement Jumps, DB Bench Press, Pull-ups, and Copenhagen Plank. There was a slight struggle on the Back Squat with the last set, and the Pallof Press was incomplete. Overall, a solid session with good effort.	[{"reason": "Bodyweight exercise, no weight adjustment needed. All sets and reps completed.", "decision": "maintain", "exercise_name": "Coutermovement Jump", "next_weight_kg": null, "actual_performance": "3 sets of 3 reps completed with bodyweight."}, {"reason": "The last set was performed at RPE 10 (0 RIR) and exceeded the target reps, indicating a potential overestimation of RPE or a very hard effort. Given the RPE, a slight regression is warranted to ensure quality and stay within the target RPE range for the mesocycle.", "decision": "regress", "exercise_name": "Back Squat", "next_weight_kg": 80, "actual_performance": "Set 1: 82.5kg for unknown reps. Set 2: 85kg for 6 reps with 0 RIR (RPE 10). Target was 2x5."}, {"reason": "All target reps were completed, with the last set exceeding the target but at a very high RPE. While technically a success, the high RPE suggests maintaining the weight to solidify performance before increasing.", "decision": "maintain", "exercise_name": "DB Bench Press", "next_weight_kg": 32, "actual_performance": "Set 1: 32kg for 6 reps with 1 RIR (RPE 9). Set 2: 32kg for 6 reps with 1 RIR (RPE 9). Set 3: 32kg for 7 reps with 0 RIR (RPE 10). Target was 3x6."}, {"reason": "All sets and reps completed. Bodyweight exercise, no weight adjustment.", "decision": "maintain", "exercise_name": "Pull-ups (Bodyweight)", "next_weight_kg": null, "actual_performance": "3 sets of 8 reps completed with bodyweight. Target was 3x8."}, {"reason": "All sets and reps completed. Bodyweight exercise, no weight adjustment.", "decision": "maintain", "exercise_name": "Copenhagen Plank", "next_weight_kg": null, "actual_performance": "3 sets of 20 reps completed with bodyweight. Target was 3x20."}, {"reason": "Only one set was completed, indicating a failure to meet the target volume. The exercise should be regressed by either reducing the resistance (if applicable) or focusing on completing the target sets at the current resistance next time.", "decision": "regress", "exercise_name": "Pallof Press 2 sec Hold", "next_weight_kg": null, "actual_performance": "Only 1 set of 8 reps completed. Target was 3x8."}]	Focus on consistent completion of all sets and reps within the target RPE for future sessions, especially for exercises where volume was not met.	2026-08-04 15:38:41.983691
\.


--
-- Data for Name: ai_briefings; Type: TABLE DATA; Schema: public; Owner: coach
--

COPY public.ai_briefings (id, user_id, session_id, session_date, note, generated_at) FROM stdin;
df906adb-8df2-4c8a-bda9-216ee8e6b40d	1add2a3d-727f-4607-aaad-759861f62394	\N	2026-07-10	Welcome to your first lower body session. We're building a strong base for September, so focus on controlled reps and hitting your target RPEs. Pay special attention to your single-leg work today, especially the Bulgarian Split Squats, to build that crucial ankle stability.	2026-07-10 11:39:34.162817
\.


--
-- Data for Name: auth_sessions; Type: TABLE DATA; Schema: public; Owner: coach
--

COPY public.auth_sessions (id, session_token, user_id, expires) FROM stdin;
\.


--
-- Data for Name: body_weight_log; Type: TABLE DATA; Schema: public; Owner: coach
--

COPY public.body_weight_log (id, user_id, date, kg) FROM stdin;
\.


--
-- Data for Name: exercise_catalog; Type: TABLE DATA; Schema: public; Owner: coach
--

COPY public.exercise_catalog (id, user_id, name, notes, default_sets, default_reps, default_weight, muscle_groups, equipment, created_by_ai) FROM stdin;
8267064c-dec6-439b-a424-e3864cecae59	1add2a3d-727f-4607-aaad-759861f62394	Back Squat	4×6 @ 80kg. RPE 6-7. Rest 3min. Foot monitoring — drop 5kg if any lateral discomfort.	\N		\N	\N	\N	f
7dd50e9d-1360-4567-bea3-ac86737ed590	1add2a3d-727f-4607-aaad-759861f62394	Bench Press Dumbbells	4×6 @ 32kg. RPE 6-7. Rest 3min.	\N		\N	\N	\N	f
a6915db5-ec7e-4d7a-bf9d-f058a0e41ab1	1add2a3d-727f-4607-aaad-759861f62394	Bent Over Barbell Row	4×8 @ 40kg. Rest 90sec.	\N		\N	\N	\N	f
be21a10c-7702-4570-85ae-2b3eb2d6657b	1add2a3d-727f-4607-aaad-759861f62394	Butterfly		\N		\N	\N	\N	f
d6ba4b6d-6adf-4e64-946e-3a180696f6f1	1add2a3d-727f-4607-aaad-759861f62394	Conditioning Circuit	3 rounds: KB Swings 20×24kg + Russian Twists 20 + Burpees 8. 90sec rest between rounds.	\N		\N	\N	\N	f
a77ed4e6-5580-48bc-b6e0-dc2ce2056de3	1add2a3d-727f-4607-aaad-759861f62394	DB Shoulder Press		\N		\N	\N	\N	f
170b526f-7738-4ec0-94a4-6f4ebc997ec8	1add2a3d-727f-4607-aaad-759861f62394	Dips (Weighted)	3×8 @ BW+7.5kg. Rest 60sec.	\N		\N	\N	\N	f
af95c27e-dd9c-49f5-b782-c9da33556cb8	1add2a3d-727f-4607-aaad-759861f62394	Face Pulls (Cable)	3×15 @ 25kg. Rest 60sec.	\N		\N	\N	\N	f
d7318d3d-eca9-41f4-ace9-cbe5bf503e40	1add2a3d-727f-4607-aaad-759861f62394	Farmers Walk		\N		\N	\N	\N	f
94a9b29f-543e-4758-8a2d-165ced59b661	1add2a3d-727f-4607-aaad-759861f62394	Hanging Leg Raises	3×18. Rest 60sec.	\N		\N	\N	\N	f
e6187fa6-ff25-4e4a-8ecb-e3be6afac518	1add2a3d-727f-4607-aaad-759861f62394	Hip Thrust or Leg Press	3×10. Moderate weight. Or Bulgarian Split Squats 3×8 each leg.	\N		\N	\N	\N	f
535e5ae4-6bfc-4d58-b538-9eb48ed23e2c	1add2a3d-727f-4607-aaad-759861f62394	Kettlebell Swings		\N		\N	\N	\N	f
c00cfc73-ba21-463c-a821-5ee7c54d9973	1add2a3d-727f-4607-aaad-759861f62394	Lateral Raises Machine		\N		\N	\N	\N	f
1db89dea-f835-4823-be26-19ef32677ca6	1add2a3d-727f-4607-aaad-759861f62394	Overhead Press Smith Machine	3×8 @ 22.5kg. Rest 90sec.	\N		\N	\N	\N	f
fbfac33a-d5ce-4f20-9886-413f64b43a08	1add2a3d-727f-4607-aaad-759861f62394	Plank	3×50sec. Rest 60sec.	\N		\N	\N	\N	f
06a97bc8-caa6-43aa-9bdd-65bdc537fa77	1add2a3d-727f-4607-aaad-759861f62394	Pull-ups (Bodyweight)	4×10. All 4 sets. Rest 90sec.	\N		\N	\N	\N	f
52bb68ae-18af-443d-af74-6f500f6b4d5d	1add2a3d-727f-4607-aaad-759861f62394	Romanian Deadlift	3×8 @ 70kg. Rest 90sec.	\N		\N	\N	\N	f
8ebd64bb-0ee4-466e-9cd9-5125ea710a56	1add2a3d-727f-4607-aaad-759861f62394	Row Machine		\N		\N	\N	\N	f
1510e334-894d-487b-b990-d0a76ed85fb8	1add2a3d-727f-4607-aaad-759861f62394	Russian Twists		\N		\N	\N	\N	f
1e2c01ec-be14-4aab-a0f3-1a8a7e3be4b4	1add2a3d-727f-4607-aaad-759861f62394	Shoulder Press Machine		\N		\N	\N	\N	f
ab5372f8-8860-49b4-92ee-9b24a3dde1b7	1add2a3d-727f-4607-aaad-759861f62394	Split Squat		\N		\N	\N	\N	f
30e54de2-e0db-4926-b871-d73848cf0f0d	1add2a3d-727f-4607-aaad-759861f62394	T-Bar Row		\N		\N	\N	\N	f
71061cba-373e-42fc-96d5-1452429aada6	1add2a3d-727f-4607-aaad-759861f62394	Triceps Overhead		\N		\N	\N	\N	f
\.


--
-- Data for Name: gym_exercises; Type: TABLE DATA; Schema: public; Owner: coach
--

COPY public.gym_exercises (id, session_id, name, target_sets, target_reps, notes, order_idx) FROM stdin;
4d87b46c-019b-42a6-ac6e-7672303c4797	de849820-dc6e-4a22-b680-b6c12b4f5572	Bench Press Dumbbells	\N		2 RIR	0
feecf194-d598-4da2-84ae-a3ab4f4286ff	de849820-dc6e-4a22-b680-b6c12b4f5572	Pull-ups (Bodyweight)	\N			1
cffb167c-bfa2-4592-8608-de3ceac851b6	de849820-dc6e-4a22-b680-b6c12b4f5572	Overhead Press Smith Machine	\N			2
6a1b243c-a035-4aa9-994d-1e01cfa898a0	de849820-dc6e-4a22-b680-b6c12b4f5572	Dips (Weighted)	\N			3
a0c61043-c1ad-46cd-9c56-afd6950eb586	de849820-dc6e-4a22-b680-b6c12b4f5572	Face Pulls (Cable)	\N			4
9b7c0d4a-d522-4ef6-9b57-efb327df2524	de849820-dc6e-4a22-b680-b6c12b4f5572	Hanging Leg Raises	\N			5
248398cc-67a2-4b33-a1f9-187a50156f37	de849820-dc6e-4a22-b680-b6c12b4f5572	Kettlebell Swings	\N			6
fa46afe4-11fe-4f1c-9ad9-0ad0a983d6d6	de849820-dc6e-4a22-b680-b6c12b4f5572	Russian Twists	\N			7
5383a210-57b0-443a-8bf7-802cb02e90cf	862e06e0-dc07-47ec-a58d-8f17ac70ad4d	Back Squat	\N			0
cf9a2043-8651-41fd-95b7-f51d6d9972ff	862e06e0-dc07-47ec-a58d-8f17ac70ad4d	Row Machine	\N			1
b94da2cb-18ec-4431-9cf7-5fd0f7b727b5	862e06e0-dc07-47ec-a58d-8f17ac70ad4d	Bench Press Dumbbells	\N			2
8016b58e-373e-418b-a42c-b76ff914091b	862e06e0-dc07-47ec-a58d-8f17ac70ad4d	Romanian Deadlift	\N			3
828b7189-529b-43e2-94d2-5d532db5056c	862e06e0-dc07-47ec-a58d-8f17ac70ad4d	Hanging Leg Raises	\N			4
5f28a4ce-4068-4d6e-aec5-a3a5986c5ce9	862e06e0-dc07-47ec-a58d-8f17ac70ad4d	Plank	\N		45 seconds	5
ce96316d-aedb-417c-98b9-e540e0e9c2a2	e3154a69-6fba-4f29-b862-49e4508c720e	Bench Press Dumbbells	\N			0
881945bf-610d-41bc-9bbd-0a467cec0108	e3154a69-6fba-4f29-b862-49e4508c720e	Pull-ups (Bodyweight)	\N			1
aeca19fa-9794-45ef-a810-a4b231d67965	e3154a69-6fba-4f29-b862-49e4508c720e	Face Pulls (Cable)	\N			2
c1bfb8fc-75d6-472f-8ba5-743d7f41b25c	e3154a69-6fba-4f29-b862-49e4508c720e	Dips (Weighted)	\N			3
1ed200b3-42c8-49f7-af88-5ee16749421d	e3154a69-6fba-4f29-b862-49e4508c720e	Hanging Leg Raises	\N			4
99a2ae20-e7a4-4910-874c-451497891016	e3154a69-6fba-4f29-b862-49e4508c720e	Kettlebell Swings	\N			5
072c4a8d-6dd6-4fd8-89fb-bd2962de51d4	e3154a69-6fba-4f29-b862-49e4508c720e	Russian Twists	\N			6
c8e55acf-7f80-43a3-bb47-0ebf6e4bae86	39f50b84-024b-4570-9cd8-bba4a30485a5	Back Squat	\N		Warmup	0
701ff54c-5db1-4f50-9a7f-781e673a4aa5	39f50b84-024b-4570-9cd8-bba4a30485a5	Bench Press Dumbbells	\N			1
d46a19da-37ec-4561-a3e6-0c4bf924feb7	39f50b84-024b-4570-9cd8-bba4a30485a5	Bent Over Barbell Row	\N			2
be0b5526-3910-4854-9b48-3b8b7e1617df	39f50b84-024b-4570-9cd8-bba4a30485a5	Romanian Deadlift	\N			3
5085802b-dece-467c-96e4-7ac477f174d4	39f50b84-024b-4570-9cd8-bba4a30485a5	Hanging Leg Raises	\N			4
7ab945d0-fba7-4ffe-a780-28a3abe98e05	39f50b84-024b-4570-9cd8-bba4a30485a5	Plank	\N		45 sec	5
e44c0f53-6d4a-4c6a-8ac4-fee407cbd854	cc1de72f-c464-4d0e-a4a7-f85c680f4f01	Bench Press Dumbbells	\N			0
8b83e314-3958-4d55-bebf-feccc00a33c8	cc1de72f-c464-4d0e-a4a7-f85c680f4f01	Pull-ups (Bodyweight)	\N			1
6e968d28-2c06-4a2d-b77c-3aa59c6e3631	cc1de72f-c464-4d0e-a4a7-f85c680f4f01	Overhead Press Smith Machine	\N			2
5e683c08-5b8f-4a3d-8874-3db7eaca70ae	cc1de72f-c464-4d0e-a4a7-f85c680f4f01	Dips (Weighted)	\N			3
d19fa4e8-d241-4734-82a5-36b03fa14dcd	cc1de72f-c464-4d0e-a4a7-f85c680f4f01	Face Pulls (Cable)	\N			4
b67ec874-2d05-484e-87c1-5cdd3815ca15	cc1de72f-c464-4d0e-a4a7-f85c680f4f01	Hanging Leg Raises	\N			5
b5dcd876-7d64-44ec-8a4a-02c4751615c9	cc1de72f-c464-4d0e-a4a7-f85c680f4f01	Kettlebell Swings	\N			6
fa77aa28-2b37-44b4-beb5-a0db18edcc7e	cc1de72f-c464-4d0e-a4a7-f85c680f4f01	Russian Twists	\N			7
6324c102-f803-4ad2-8b9d-4575cfc78648	49979cf7-f3a9-4aff-a6e0-164eba6c9a93	Back Squat	\N			0
798f7355-27d8-4584-bf54-77a9d7c386bf	49979cf7-f3a9-4aff-a6e0-164eba6c9a93	Romanian Deadlift	\N			1
aef9c7e6-51cb-4066-9152-a4424e277ed7	49979cf7-f3a9-4aff-a6e0-164eba6c9a93	Bent Over Barbell Row	\N			2
f62658bd-1aa8-45a6-a193-25fa5f516276	49979cf7-f3a9-4aff-a6e0-164eba6c9a93	Hanging Leg Raises	\N			3
2ec1edce-cf2d-4743-a1d4-fefc75867a25	8f6dc117-b150-4b58-a476-066eb639f6a7	Bench Press Dumbbells	\N			0
239f4a2c-f3a7-4ce9-8aff-485cc3bd1370	8f6dc117-b150-4b58-a476-066eb639f6a7	Pull-ups (Bodyweight)	\N			1
7e6a2eb7-ccb5-4881-9e50-9a05955716fb	8f6dc117-b150-4b58-a476-066eb639f6a7	Overhead Press Smith Machine	\N		Hard	2
8254be9c-9259-4ef7-9305-7f8eab88f587	8f6dc117-b150-4b58-a476-066eb639f6a7	Dips (Weighted)	\N			3
793851cf-b47b-4941-a0da-9c01fb8b85f3	8f6dc117-b150-4b58-a476-066eb639f6a7	Face Pulls (Cable)	\N			4
36ae5779-f43f-4a72-a6be-ce8435125b18	8f6dc117-b150-4b58-a476-066eb639f6a7	Conditioning Circuit	\N		KB swing: 16 kg, Twists: 8kg DB	5
f6311754-c404-41ab-a4dd-b1f5d3a9aa44	71e772e6-1325-4266-ae03-1234528dec2c	Bench Press Dumbbells	\N			0
d4cb0b31-108b-4a83-a783-922841f8a49c	71e772e6-1325-4266-ae03-1234528dec2c	Pull-ups (Bodyweight)	\N			1
af34de3d-26e0-4e73-971a-9cb378a637ec	71e772e6-1325-4266-ae03-1234528dec2c	DB Shoulder Press	\N			2
3e485eb0-ea92-45ea-9cfc-df8b1acedb6f	71e772e6-1325-4266-ae03-1234528dec2c	Dips (Weighted)	\N			3
b2abd3f6-1cff-4496-a59b-f289aeedee8c	71e772e6-1325-4266-ae03-1234528dec2c	T-Bar Row	\N			4
c84570b2-237c-4a7e-ab0f-b62f575069a0	71e772e6-1325-4266-ae03-1234528dec2c	Face Pulls (Cable)	\N			5
a72906f5-e0fe-4b7b-9ee2-432947c8691d	a2d70753-783e-428a-9cb4-496be9d6ee88	Back Squat	\N			0
bd7135f9-0e05-4b80-a114-de1c23988f68	a2d70753-783e-428a-9cb4-496be9d6ee88	Romanian Deadlift	\N			1
2458fa1a-0546-431e-bc7e-d8859bde639a	a2d70753-783e-428a-9cb4-496be9d6ee88	Split Squat	\N		Weight per side, 32 kg completely	2
020cc095-9f4e-4f3c-956a-fbd95abe1dc3	a2d70753-783e-428a-9cb4-496be9d6ee88	Hanging Leg Raises	\N			3
a62b34a6-9113-4eec-8486-717c72160317	a2d70753-783e-428a-9cb4-496be9d6ee88	Farmers Walk	\N		Easy	4
eae3e3a6-28b3-436b-ac8b-a6b50ce1c102	4fc44296-4f36-499f-ad7d-113608c6bd24	Bench Press Dumbbells	\N			0
d71a608e-d92f-45ff-8927-c651c2f0542c	4fc44296-4f36-499f-ad7d-113608c6bd24	Pull-ups (Bodyweight)	\N			1
4cc9a1b9-b2d9-4b12-b1b5-b2b5ecc70015	4fc44296-4f36-499f-ad7d-113608c6bd24	DB Shoulder Press	\N			2
d66a591e-976f-41ae-8297-e81a1e499ec7	4fc44296-4f36-499f-ad7d-113608c6bd24	Dips (Weighted)	\N			3
56071e84-7636-4492-850b-5492b97bbff0	81f90a8a-5ff8-4024-a63e-0dc483e4ad8d	Back Squat	\N			0
7a30ea29-9c66-4f38-bbea-38949feec451	81f90a8a-5ff8-4024-a63e-0dc483e4ad8d	Romanian Deadlift	\N			1
c7f9789a-22c6-4cbc-b2ca-0d168dadbe22	81f90a8a-5ff8-4024-a63e-0dc483e4ad8d	Split Squat	\N			2
feffb16c-865b-4330-ab72-1cc546732207	81f90a8a-5ff8-4024-a63e-0dc483e4ad8d	Farmers Walk	\N			3
ba892718-35e0-47e3-8f75-31aa42dc4b4e	81f90a8a-5ff8-4024-a63e-0dc483e4ad8d	Hanging Leg Raises	\N			4
f4c8cc69-cea9-46b2-bbda-503569eee6fa	f5f087b0-ae75-4f1b-a8fe-ab129ad618c3	Bench Press Dumbbells	\N		Switches to 32 kg, 34 was too heavy for 6 reps	0
66083d28-b5ab-42a3-b5b1-ecd329db415b	f5f087b0-ae75-4f1b-a8fe-ab129ad618c3	Pull-ups (Bodyweight)	\N			1
ca82590e-4626-4c36-9d4c-ae0db230d1d4	f5f087b0-ae75-4f1b-a8fe-ab129ad618c3	DB Shoulder Press	\N			2
374a26a1-59cb-43a9-939b-5e5c318b09db	f5f087b0-ae75-4f1b-a8fe-ab129ad618c3	Dips (Weighted)	\N			3
ad0ef543-b48a-4cbe-af9d-90778c042b34	f5f087b0-ae75-4f1b-a8fe-ab129ad618c3	T-Bar Row	\N			4
dbf27d78-2d5f-43c2-93cb-a12996b1084c	82311b78-527b-4487-b69f-d263183836c1	Back Squat	\N		Feels like i push more with left side	0
fe68684b-9b23-43ee-ba2e-fe54b38e8305	82311b78-527b-4487-b69f-d263183836c1	Romanian Deadlift	\N			1
814027a8-92ea-4a8e-b013-147be08b66bd	82311b78-527b-4487-b69f-d263183836c1	Split Squat	\N			2
578790a2-ce8e-4622-a0b7-e94ea382218b	82311b78-527b-4487-b69f-d263183836c1	Farmers Walk	\N			3
d5413358-2f06-4afd-87a8-bfeb3c74b4c3	82311b78-527b-4487-b69f-d263183836c1	Hanging Leg Raises	\N			4
9493d235-f95b-4345-8b7e-a22d81d9398f	c23180ce-2f1a-4be7-b5fe-89e7d66f8a0d	Bench Press Dumbbells	\N			0
8ed4f949-75a7-4b0c-bb84-b476979e1d29	c23180ce-2f1a-4be7-b5fe-89e7d66f8a0d	Pull-ups (Bodyweight)	\N			1
51cf9550-ef19-490b-8e00-c6ca5218f39e	c23180ce-2f1a-4be7-b5fe-89e7d66f8a0d	DB Shoulder Press	\N			2
4c470fc0-55c2-4f17-80ee-c879e1cf6de1	c23180ce-2f1a-4be7-b5fe-89e7d66f8a0d	Dips (Weighted)	\N		Belt for additional weight not available right now	3
00988256-d701-4519-9f55-c3c35a0f2f70	c23180ce-2f1a-4be7-b5fe-89e7d66f8a0d	T-Bar Row	\N			4
9a85ea56-7735-4496-a53b-91615a3d233c	f09428c3-183e-4a22-bb9c-67c6a26efa1b	Bench Press Dumbbells	\N			0
d12ef360-ee15-4725-8c77-7182f20630a6	f09428c3-183e-4a22-bb9c-67c6a26efa1b	Pull-ups (Bodyweight)	\N			1
bc6f4849-e18e-4eb1-9a93-b0ecd751704b	f09428c3-183e-4a22-bb9c-67c6a26efa1b	Shoulder Press Machine	\N			2
671b07dc-ea97-4f39-8e15-18fb7f22e433	f09428c3-183e-4a22-bb9c-67c6a26efa1b	Dips (Weighted)	\N			3
ad2f42d1-dfdf-4626-a775-1b09300db017	f09428c3-183e-4a22-bb9c-67c6a26efa1b	Bent Over Barbell Row	\N			4
eb834825-1914-47e3-87fa-bb2811fa7d41	f09428c3-183e-4a22-bb9c-67c6a26efa1b	Face Pulls (Cable)	\N			5
e948d93d-17fe-4c9e-8480-517618cb3ff6	799fd57e-4e31-4e33-b839-5d4d1a9a7654	Bench Press Dumbbells	\N			0
41fc7a96-7e68-44f0-8813-b17fe7acff9b	799fd57e-4e31-4e33-b839-5d4d1a9a7654	Pull-ups (Bodyweight)	\N			1
ad766299-d735-4365-94d8-5603d1c54807	799fd57e-4e31-4e33-b839-5d4d1a9a7654	Dips (Weighted)	\N			2
8f8032a3-a759-4080-b427-d0695eeb6206	799fd57e-4e31-4e33-b839-5d4d1a9a7654	Bent Over Barbell Row	\N			3
8dc1e82f-744d-4dbb-9c99-52fd08ef3b4c	8c2aa9cc-2102-4632-ac3f-81fce13ea66e	DB Bench Press	4	6	Was 34kg pre-gap. Tuesday did 32-34kg briefly. Aim 4x6@32kg, RPE 7-8.	0
e8cb43e5-6c67-4414-839e-f947fec0380f	8c2aa9cc-2102-4632-ac3f-81fce13ea66e	Pull-ups (Bodyweight)	3	8	4×10. All 4 sets. Rest 90sec.	1
18da4b42-f763-4b03-a7ff-5c622de5c0bd	8c2aa9cc-2102-4632-ac3f-81fce13ea66e	DB Shoulder Press	3	8		2
b7ade734-f808-4e9f-91df-bcaf9d4be9e2	8c2aa9cc-2102-4632-ac3f-81fce13ea66e	T-Bar Row	3	8		3
67c0879d-9424-4d22-a547-5527a003760b	8c2aa9cc-2102-4632-ac3f-81fce13ea66e	Face Pulls (Cable)	3	15	3×15 @ 25kg. Rest 60sec.	4
f76e06c2-5743-4029-9526-c81f5ef999e7	3c0dca44-ba75-4440-b6ae-df6d3f28c49d	Coutermovement Jump	3	3		0
fdeda02b-5f8b-4bd1-abb2-597717d9cc21	3c0dca44-ba75-4440-b6ae-df6d3f28c49d	Back Squat	2	5		1
77476d0e-baab-4ac0-9daf-74eb3414ce5d	3c0dca44-ba75-4440-b6ae-df6d3f28c49d	DB Bench Press	3	6	Focus on controlled movement and full range of motion. Maintain shoulder stability.	2
34be82de-1c80-4c28-b3c4-47a8a85b8360	3c0dca44-ba75-4440-b6ae-df6d3f28c49d	Pull-ups (Bodyweight)	3	8		3
16e8951e-566b-4124-b91a-3f44a5fc6181	3c0dca44-ba75-4440-b6ae-df6d3f28c49d	Split Squat	3	8		4
4e0262c4-4861-4c85-a571-bf3f4a62c7fa	3c0dca44-ba75-4440-b6ae-df6d3f28c49d	Copenhagen Plank	3	20		5
00e5954b-3dc3-4659-a7a4-64d963a3c1bd	3c0dca44-ba75-4440-b6ae-df6d3f28c49d	Pallof Press 2 sec Hold	3	8		6
ba31059d-b6fc-4cc2-9645-943f89397124	3c0dca44-ba75-4440-b6ae-df6d3f28c49d	Tibialis Raises	2	15		7
2b0553d3-905b-4d95-9661-ff9050c1929b	d1641397-37e1-4863-aebb-076f1fd65f56	Coutermovement Jump	3	3		0
b58d7c4c-da74-42c4-88a8-ffcf38345be1	d1641397-37e1-4863-aebb-076f1fd65f56	Back Squat	2	5		1
9ae6ccce-66cc-4f0e-8c17-d4382cc399c5	d1641397-37e1-4863-aebb-076f1fd65f56	DB Bench Press	3	6	Focus on controlled movement and full range of motion. Maintain shoulder stability.	2
f47cf19c-ca78-4e75-bb94-34478c8e9365	d1641397-37e1-4863-aebb-076f1fd65f56	Pull-ups (Bodyweight)	3	8		3
9b2aefa8-3c95-4fd8-9019-56473e2a84d2	d1641397-37e1-4863-aebb-076f1fd65f56	Split Squat	3	8		4
3307d676-aa14-497f-8f4c-26ed7350ea43	d1641397-37e1-4863-aebb-076f1fd65f56	Copenhagen Plank	3	20		5
98cb8dea-a2c2-4cb9-b311-83aac1a8c031	d1641397-37e1-4863-aebb-076f1fd65f56	Pallof Press 2 sec Hold	3	8		6
843c68d6-4182-42ff-a984-77f76c197f4e	d1641397-37e1-4863-aebb-076f1fd65f56	Tibialis Raises	2	15		7
b8bfd97f-980a-421f-ba8a-32c37c463dce	95a89d8f-45c9-4621-a141-561123f391d0	Bench Press Dumbbells	\N		4×6 @ 32kg. RPE 6-7. Rest 3min.	0
b779017f-082e-43d7-a656-5ad19f1c37a0	95a89d8f-45c9-4621-a141-561123f391d0	Pull-ups (Bodyweight)	\N		4×10. All 4 sets. Rest 90sec.	1
021d8c25-2e61-4c54-9c34-ecac57f31fd1	95a89d8f-45c9-4621-a141-561123f391d0	Lateral Raises Machine	\N			2
326dd201-df01-4557-b92e-8f130ff5ce70	95a89d8f-45c9-4621-a141-561123f391d0	Shoulder Press Machine	\N			3
a9adcc0c-94d6-4a85-b8d2-f47dc419184f	95a89d8f-45c9-4621-a141-561123f391d0	Triceps Overhead	\N			4
45ea96db-e45c-4c8e-b833-d8e163318684	95a89d8f-45c9-4621-a141-561123f391d0	Butterfly	\N			5
726fb72d-7e3a-4633-a004-81b09ee0260a	bcd280dc-d9a7-4a6d-ae49-89a0affe3b93	DB Bench Press	4	6	Confirmed working weight. Last session Jun 27 hit 34, 32, 32, 32. Target 4x6 at RPE 7.	0
76e4b7b6-b546-4a99-9493-72cb6ed61468	bcd280dc-d9a7-4a6d-ae49-89a0affe3b93	Pull-ups (Bodyweight)	4	10	4×10. All 4 sets. Rest 90sec.	1
ea52b922-cfbf-4ee1-9b43-3815869e1bf5	bcd280dc-d9a7-4a6d-ae49-89a0affe3b93	Shoulder Press Machine	\N			2
936464d1-8bb9-431b-991e-a94b7f18adf2	bcd280dc-d9a7-4a6d-ae49-89a0affe3b93	Dips (Weighted)	3	6-8	3×8 @ BW+7.5kg. Rest 60sec.	3
93f7c3c9-95f3-4bf9-b5f0-19077e8c552c	bcd280dc-d9a7-4a6d-ae49-89a0affe3b93	T-bar Row	3	8		4
2f0e3a61-85e4-4a05-b503-f04b5dfd3ede	bcd280dc-d9a7-4a6d-ae49-89a0affe3b93	Face Pulls (Cable)	3	15	3×15 @ 25kg. Rest 60sec.	5
d1df13cd-8e9b-43b7-8db3-5dee0a872d13	51369348-bb53-49c5-92da-d658b6063cf2	Coutermovement Jump	3	3		0
cb5db3c8-a12a-4627-9a1f-1b05219f8add	51369348-bb53-49c5-92da-d658b6063cf2	Back Squat	2	5		1
ee3925d9-79f2-4f35-b227-61ed7db0d25c	51369348-bb53-49c5-92da-d658b6063cf2	DB Bench Press	3	6	Focus on controlled movement and full range of motion. Maintain shoulder stability.	2
c2dc29fb-2d4e-4fef-9c70-efcb06f38bfd	51369348-bb53-49c5-92da-d658b6063cf2	Pull-ups (Bodyweight)	3	8		3
eb89f2ec-8a58-4c92-afd0-d511fd80617c	51369348-bb53-49c5-92da-d658b6063cf2	Split Squat	3	8		4
d6760a3d-3429-46bc-88b1-3a02244f4c6e	51369348-bb53-49c5-92da-d658b6063cf2	Copenhagen Plank	3	20		5
5898dc9c-c93b-47bb-937c-8a5eb8c6bbea	51369348-bb53-49c5-92da-d658b6063cf2	Pallof Press 2 sec Hold	3	8		6
3872f2db-299c-482c-8ed8-ed7b067b5251	51369348-bb53-49c5-92da-d658b6063cf2	Tibialis Raises	2	15		7
\.


--
-- Data for Name: gym_sessions; Type: TABLE DATA; Schema: public; Owner: coach
--

COPY public.gym_sessions (id, user_id, date, name, session_type, started_at, finished_at, notes, created_at, updated_at) FROM stdin;
de849820-dc6e-4a22-b680-b6c12b4f5572	1add2a3d-727f-4607-aaad-759861f62394	2026-04-23	Gym session	\N	2026-04-23 18:02:53	2026-04-23 19:12:32		2026-07-10 06:49:22.257266	2026-07-10 06:49:22.257266
862e06e0-dc07-47ec-a58d-8f17ac70ad4d	1add2a3d-727f-4607-aaad-759861f62394	2026-04-27	Gym session	\N	2026-04-27 16:14:13	2026-04-27 17:43:49		2026-07-10 06:49:22.274405	2026-07-10 06:49:22.274405
e3154a69-6fba-4f29-b862-49e4508c720e	1add2a3d-727f-4607-aaad-759861f62394	2026-05-02	Gym session	\N	2026-05-02 09:58:56	2026-05-02 11:15:45		2026-07-10 06:49:22.284925	2026-07-10 06:49:22.284925
39f50b84-024b-4570-9cd8-bba4a30485a5	1add2a3d-727f-4607-aaad-759861f62394	2026-05-04	Gym session	\N	2026-05-04 16:07:50	2026-05-04 17:24:56		2026-07-10 06:49:22.298395	2026-07-10 06:49:22.298395
cc1de72f-c464-4d0e-a4a7-f85c680f4f01	1add2a3d-727f-4607-aaad-759861f62394	2026-05-06	Gym session	\N	2026-05-06 14:31:56	2026-05-06 15:56:05		2026-07-10 06:49:22.308882	2026-07-10 06:49:22.308882
49979cf7-f3a9-4aff-a6e0-164eba6c9a93	1add2a3d-727f-4607-aaad-759861f62394	2026-05-14	Gym session	\N	2026-05-14 09:12:45	2026-05-14 10:06:20		2026-07-10 06:49:22.322376	2026-07-10 06:49:22.322376
8f6dc117-b150-4b58-a476-066eb639f6a7	1add2a3d-727f-4607-aaad-759861f62394	2026-05-16	Gym session	\N	2026-05-16 10:03:20	2026-05-16 11:25:08		2026-07-10 06:49:22.329958	2026-07-10 06:49:22.329958
71e772e6-1325-4266-ae03-1234528dec2c	1add2a3d-727f-4607-aaad-759861f62394	2026-05-20	Gym session	\N	2026-05-20 08:35:35	2026-05-20 09:35:06		2026-07-10 06:49:22.340123	2026-07-10 06:49:22.340123
a2d70753-783e-428a-9cb4-496be9d6ee88	1add2a3d-727f-4607-aaad-759861f62394	2026-05-28	Gym session	\N	2026-05-28 16:02:43	2026-05-28 16:59:22		2026-07-10 06:49:22.350489	2026-07-10 06:49:22.350489
4fc44296-4f36-499f-ad7d-113608c6bd24	1add2a3d-727f-4607-aaad-759861f62394	2026-05-30	Gym session	\N	2026-05-30 08:51:30	2026-05-30 09:31:04		2026-07-10 06:49:22.358919	2026-07-10 06:49:22.358919
81f90a8a-5ff8-4024-a63e-0dc483e4ad8d	1add2a3d-727f-4607-aaad-759861f62394	2026-06-01	Gym session	\N	2026-06-01 07:46:16	2026-06-01 08:51:33		2026-07-10 06:49:22.365372	2026-07-10 06:49:22.365372
f5f087b0-ae75-4f1b-a8fe-ab129ad618c3	1add2a3d-727f-4607-aaad-759861f62394	2026-06-02	Gym session	\N	2026-06-02 15:54:02	2026-06-02 16:40:37		2026-07-10 06:49:22.378993	2026-07-10 06:49:22.378993
82311b78-527b-4487-b69f-d263183836c1	1add2a3d-727f-4607-aaad-759861f62394	2026-06-06	Gym session	\N	2026-06-06 12:35:13	2026-06-06 13:33:30		2026-07-10 06:49:22.38886	2026-07-10 06:49:22.38886
c23180ce-2f1a-4be7-b5fe-89e7d66f8a0d	1add2a3d-727f-4607-aaad-759861f62394	2026-06-10	Gym session	\N	2026-06-10 15:38:12	2026-06-10 16:37:58		2026-07-10 06:49:22.397396	2026-07-10 06:49:22.397396
f09428c3-183e-4a22-bb9c-67c6a26efa1b	1add2a3d-727f-4607-aaad-759861f62394	2026-06-14	Gym session	\N	2026-06-14 10:51:12	2026-06-14 12:12:11		2026-07-10 06:49:22.406009	2026-07-10 06:49:22.406009
799fd57e-4e31-4e33-b839-5d4d1a9a7654	1add2a3d-727f-4607-aaad-759861f62394	2026-06-23	Gym session	\N	2026-06-23 17:52:26	2026-06-26 12:17:32.819		2026-07-10 06:49:22.415185	2026-07-10 06:49:22.415185
8c2aa9cc-2102-4632-ac3f-81fce13ea66e	1add2a3d-727f-4607-aaad-759861f62394	2026-06-27	Gym — Upper	\N	2026-06-27 08:30:54.46	2026-06-27 09:47:54.646		2026-07-10 06:49:22.421944	2026-07-10 06:49:22.421944
3c0dca44-ba75-4440-b6ae-df6d3f28c49d	1add2a3d-727f-4607-aaad-759861f62394	2026-07-26	Gym Session 1	dadc2ecb-4cf8-482b-ae0c-537a1e4169b2	2026-07-26 07:29:53.593	2026-07-26 08:34:31.344		2026-07-26 07:29:51.428183	2026-07-26 08:34:29.455
d1641397-37e1-4863-aebb-076f1fd65f56	1add2a3d-727f-4607-aaad-759861f62394	2026-08-04	Gym Session 1	dadc2ecb-4cf8-482b-ae0c-537a1e4169b2	2026-08-04 14:40:29.625	2026-08-04 15:38:50.373		2026-08-04 14:40:14.581582	2026-08-04 15:38:37.252
95a89d8f-45c9-4621-a141-561123f391d0	1add2a3d-727f-4607-aaad-759861f62394	2026-07-07	Gym session	\N	2026-07-07 15:30:44.308	2026-07-10 15:02:27.959		2026-07-10 06:49:22.440818	2026-07-10 15:01:38.785
bcd280dc-d9a7-4a6d-ae49-89a0affe3b93	1add2a3d-727f-4607-aaad-759861f62394	2026-06-30	Gym — Upper	\N	2026-06-29 07:19:48.575	2026-07-10 15:02:40.211		2026-07-10 06:49:22.431157	2026-07-10 15:01:50.983
51369348-bb53-49c5-92da-d658b6063cf2	1add2a3d-727f-4607-aaad-759861f62394	2026-07-16	Gym Session 1	dadc2ecb-4cf8-482b-ae0c-537a1e4169b2	2026-07-16 14:44:26.192	2026-07-16 15:55:58.166		2026-07-16 14:43:27.264241	2026-07-16 15:55:01.458
\.


--
-- Data for Name: gym_sets; Type: TABLE DATA; Schema: public; Owner: coach
--

COPY public.gym_sets (id, exercise_id, set_no, reps, weight, rpe, done, rir) FROM stdin;
16aa87a4-872f-47c4-bd9d-ac00e087b302	4d87b46c-019b-42a6-ac6e-7672303c4797	1	5	28.00	\N	t	\N
e6c6d85f-b113-4f32-98ed-aba3edd8755d	4d87b46c-019b-42a6-ac6e-7672303c4797	2	3	32.00	\N	t	\N
12e1f08a-e699-4a5c-b55e-18c609add1cc	4d87b46c-019b-42a6-ac6e-7672303c4797	3	5	30.00	\N	t	\N
04bd9397-9f3d-45d8-9afc-2102ffd31dbe	4d87b46c-019b-42a6-ac6e-7672303c4797	4	5	30.00	\N	t	\N
f43ba2f7-9e63-4ef7-a744-dfd738c8a733	feecf194-d598-4da2-84ae-a3ab4f4286ff	1	10	0.00	\N	t	\N
0870bb25-426b-4992-ae4f-0c3fd712e3cd	feecf194-d598-4da2-84ae-a3ab4f4286ff	2	9	0.00	\N	t	\N
dcad286e-7c42-4441-b4db-e7941ff839b4	feecf194-d598-4da2-84ae-a3ab4f4286ff	3	7	0.00	\N	t	\N
02b31d10-0e6a-4e92-9367-3d54ad43f974	feecf194-d598-4da2-84ae-a3ab4f4286ff	4	7	0.00	\N	t	\N
09152b5e-fa73-43d6-a227-2e02ae9fdf13	cffb167c-bfa2-4592-8608-de3ceac851b6	1	8	15.00	\N	t	\N
50328821-4503-4b32-ad1f-da4f36f47011	cffb167c-bfa2-4592-8608-de3ceac851b6	2	8	15.00	\N	t	\N
f2db8939-e20f-47c6-b5b8-cb56e3200ac3	cffb167c-bfa2-4592-8608-de3ceac851b6	3	8	15.00	\N	t	\N
ae96e52a-1535-4c95-a9c6-b7e119e8f69c	6a1b243c-a035-4aa9-994d-1e01cfa898a0	1	8	0.00	\N	t	\N
93d5c0be-f864-4c7c-811a-06a324d3371c	6a1b243c-a035-4aa9-994d-1e01cfa898a0	2	6	0.00	\N	t	\N
f6691f43-24b5-4a4e-b475-3436d77f9685	6a1b243c-a035-4aa9-994d-1e01cfa898a0	3	7	0.00	\N	t	\N
8c01deb4-e63c-4fae-b226-bf80f5ac3efb	a0c61043-c1ad-46cd-9c56-afd6950eb586	1	15	13.50	\N	t	\N
8f65bc7f-673e-4839-87b9-32545c591ac7	a0c61043-c1ad-46cd-9c56-afd6950eb586	2	15	17.00	\N	t	\N
5bec781b-b2b8-4a16-93db-710c5945b1ea	a0c61043-c1ad-46cd-9c56-afd6950eb586	3	15	17.00	\N	t	\N
1cafa24e-6648-4da3-9fb5-21a9accd850b	9b7c0d4a-d522-4ef6-9b57-efb327df2524	1	15	0.00	\N	t	\N
a1ec1642-21b2-4036-9976-cb0ac471ef82	9b7c0d4a-d522-4ef6-9b57-efb327df2524	2	15	0.00	\N	t	\N
e138e287-034b-4bdb-aa76-fd2b45b40919	9b7c0d4a-d522-4ef6-9b57-efb327df2524	3	15	0.00	\N	t	\N
a3c1ed91-5f3f-4738-ab3b-7ef94ddc53b7	248398cc-67a2-4b33-a1f9-187a50156f37	1	15	16.00	\N	t	\N
4d46e95c-6816-49d6-913e-007668b27724	248398cc-67a2-4b33-a1f9-187a50156f37	2	15	16.00	\N	t	\N
1a321731-a2c2-4dc3-a6cc-05160487f6c7	248398cc-67a2-4b33-a1f9-187a50156f37	3	15	16.00	\N	t	\N
df3fa626-373b-4e66-9644-3ae446f75c03	fa46afe4-11fe-4f1c-9ad9-0ad0a983d6d6	1	30	0.00	\N	t	\N
213fd467-b282-4764-b0d3-d780f84f58f1	fa46afe4-11fe-4f1c-9ad9-0ad0a983d6d6	2	30	0.00	\N	t	\N
3690bf07-4e3f-4bc8-b562-04cb43b6df81	fa46afe4-11fe-4f1c-9ad9-0ad0a983d6d6	3	30	0.00	\N	t	\N
3ab4d9f0-53f0-4314-914b-279fcbc50e40	5383a210-57b0-443a-8bf7-802cb02e90cf	1	6	80.00	\N	t	\N
77958c46-f245-490f-ba29-5f3fe12c4708	5383a210-57b0-443a-8bf7-802cb02e90cf	2	5	90.00	\N	t	\N
cfb0cd7b-7b46-4fc0-af29-71b2351a725c	5383a210-57b0-443a-8bf7-802cb02e90cf	3	3	90.00	\N	t	\N
ad9bc3a2-d6df-4e06-96ac-63009b024906	5383a210-57b0-443a-8bf7-802cb02e90cf	4	6	80.00	\N	t	\N
737dabe2-318b-4ecf-aa67-10f06ca5bcb2	cf9a2043-8651-41fd-95b7-f51d6d9972ff	1	8	30.00	\N	t	\N
29b34c80-79e4-465d-ba75-211438b0712f	cf9a2043-8651-41fd-95b7-f51d6d9972ff	2	8	40.00	\N	t	\N
fc43756e-54ba-490c-a81f-6952382fd76c	cf9a2043-8651-41fd-95b7-f51d6d9972ff	3	8	40.00	\N	t	\N
9bedff3c-b44e-47cb-817d-3bf88d774861	cf9a2043-8651-41fd-95b7-f51d6d9972ff	4	8	40.00	\N	t	\N
72444aab-80fc-46e0-b617-750d15b67f30	b94da2cb-18ec-4431-9cf7-5fd0f7b727b5	1	6	30.00	\N	t	\N
c55953db-1ec7-4790-8b8d-c25212073edc	b94da2cb-18ec-4431-9cf7-5fd0f7b727b5	2	6	30.00	\N	t	\N
417a303a-eaca-47e8-9dec-d34c84dc1349	b94da2cb-18ec-4431-9cf7-5fd0f7b727b5	3	7	30.00	\N	t	\N
1c029e95-f42b-4096-a050-989dff2e626f	b94da2cb-18ec-4431-9cf7-5fd0f7b727b5	4	5	30.00	\N	t	\N
2c9e4108-4825-4186-92fc-704c27ee603d	8016b58e-373e-418b-a42c-b76ff914091b	1	10	60.00	\N	t	\N
a331e3b0-2575-4804-b50e-8c80b79e85c3	8016b58e-373e-418b-a42c-b76ff914091b	2	10	70.00	\N	t	\N
d6abba3c-0e5e-43f2-96c9-8f8401aa9e2d	8016b58e-373e-418b-a42c-b76ff914091b	3	10	70.00	\N	t	\N
5555ae78-9a39-4fb5-ac77-5bc3cef8e604	828b7189-529b-43e2-94d2-5d532db5056c	1	15	0.00	\N	t	\N
110bb4a1-9a20-41f5-8e3b-41514b3c2aa1	828b7189-529b-43e2-94d2-5d532db5056c	2	15	0.00	\N	t	\N
66d485c8-d2d2-463a-94d9-938913cc472e	828b7189-529b-43e2-94d2-5d532db5056c	3	15	0.00	\N	t	\N
64973b3b-cdce-4ebb-a0fd-3952bf33751d	5f28a4ce-4068-4d6e-aec5-a3a5986c5ce9	1	3	0.00	\N	t	\N
d4c8b380-50ca-4886-ab53-a13c95da88b3	ce96316d-aedb-417c-98b9-e540e0e9c2a2	1	5	32.00	\N	t	\N
83ddd555-fcfc-4ae5-8ce3-48fded0e8d36	ce96316d-aedb-417c-98b9-e540e0e9c2a2	2	5	32.00	\N	t	\N
34c11e8e-e8b6-4133-a6e6-dd5bff0ffbc2	ce96316d-aedb-417c-98b9-e540e0e9c2a2	3	5	32.00	\N	t	\N
54fde221-ce79-4d5d-9f27-13c99dbfeffc	ce96316d-aedb-417c-98b9-e540e0e9c2a2	4	5	32.00	\N	t	\N
52e4f7da-fcb7-4962-ae6d-844ac4a2ff1c	881945bf-610d-41bc-9bbd-0a467cec0108	1	8	0.00	\N	t	\N
ab1d969e-df7f-4a6e-81bf-fac82555c46b	881945bf-610d-41bc-9bbd-0a467cec0108	2	8	0.00	\N	t	\N
4eb21825-7530-4a6a-acf2-347367e3cfaa	881945bf-610d-41bc-9bbd-0a467cec0108	3	8	0.00	\N	t	\N
90db724f-5681-4116-9321-d9f834291946	881945bf-610d-41bc-9bbd-0a467cec0108	4	8	0.00	\N	t	\N
9c92c02a-6553-41f2-a851-39ddfe9db8be	aeca19fa-9794-45ef-a810-a4b231d67965	1	15	22.50	\N	t	\N
ed3f6cd6-c094-4eeb-9d9a-7ab9498d0813	aeca19fa-9794-45ef-a810-a4b231d67965	2	15	22.50	\N	t	\N
4d6e974f-9935-4e99-81d4-0279e44e406b	aeca19fa-9794-45ef-a810-a4b231d67965	3	15	22.50	\N	t	\N
dcc1ea86-7974-4e20-ae85-64968e0298be	c1bfb8fc-75d6-472f-8ba5-743d7f41b25c	1	10	0.00	\N	t	\N
3fa161bd-9839-4187-8017-edcc03e7a3a2	c1bfb8fc-75d6-472f-8ba5-743d7f41b25c	2	10	0.00	\N	t	\N
85024b95-2066-4b2d-9a37-b12e2e840c90	c1bfb8fc-75d6-472f-8ba5-743d7f41b25c	3	10	0.00	\N	t	\N
197b9bca-856e-4a86-b6db-b019b6ae9cfd	1ed200b3-42c8-49f7-af88-5ee16749421d	1	15	0.00	\N	t	\N
53952484-d86b-4085-aee2-b9bcb014995e	1ed200b3-42c8-49f7-af88-5ee16749421d	2	15	0.00	\N	t	\N
4cf80f4d-6d5f-4a2a-9d64-e93fa0009b9c	1ed200b3-42c8-49f7-af88-5ee16749421d	3	15	0.00	\N	t	\N
62635f23-ba09-4b49-82f5-748b34c76659	99a2ae20-e7a4-4910-874c-451497891016	1	20	16.00	\N	t	\N
8f7fddef-1773-4b84-85d3-020b4a889885	99a2ae20-e7a4-4910-874c-451497891016	2	20	20.00	\N	t	\N
30ca0bf2-652e-4e8d-90aa-d14658d62811	99a2ae20-e7a4-4910-874c-451497891016	3	20	20.00	\N	t	\N
a80a0484-6d36-46e4-96b3-e06e6417b5fa	072c4a8d-6dd6-4fd8-89fb-bd2962de51d4	1	30	0.00	\N	t	\N
aaa9e5f5-0e1c-4de4-bd74-05eb9d75776f	072c4a8d-6dd6-4fd8-89fb-bd2962de51d4	2	30	0.00	\N	t	\N
fdbb8c04-7960-42ed-bf63-09113f47facf	072c4a8d-6dd6-4fd8-89fb-bd2962de51d4	3	30	0.00	\N	t	\N
5f68c8fb-6a25-4c59-9e2b-b4f43a8f8ee6	c8e55acf-7f80-43a3-bb47-0ebf6e4bae86	1	3	60.00	\N	t	\N
3ea21aeb-775b-4774-883e-5bbf1a2ea4cf	c8e55acf-7f80-43a3-bb47-0ebf6e4bae86	2	6	80.00	\N	t	\N
ecc50205-2c4c-4e85-bf0a-327929393555	c8e55acf-7f80-43a3-bb47-0ebf6e4bae86	3	5	90.00	\N	t	\N
2ac0d2e9-de9c-4012-979d-75c5c35ed46c	c8e55acf-7f80-43a3-bb47-0ebf6e4bae86	4	5	80.00	\N	t	\N
d1e70dd0-b75c-4a37-9651-c7870a167836	c8e55acf-7f80-43a3-bb47-0ebf6e4bae86	5	5	80.00	\N	t	\N
78431b39-77ba-4098-bc7d-cc4a36dcec26	701ff54c-5db1-4f50-9a7f-781e673a4aa5	1	6	32.00	\N	t	\N
ced37bf0-7984-4504-8b1f-a09b5a126a5c	701ff54c-5db1-4f50-9a7f-781e673a4aa5	2	6	32.00	\N	t	\N
a43a1a44-d39a-4d00-b478-95931a4784cd	701ff54c-5db1-4f50-9a7f-781e673a4aa5	3	6	32.00	\N	t	\N
ce327512-5697-4a16-92a6-cfc941399475	701ff54c-5db1-4f50-9a7f-781e673a4aa5	4	4	32.00	\N	t	\N
29b1abdb-cc90-4332-9861-70a46b001c56	d46a19da-37ec-4561-a3e6-0c4bf924feb7	1	8	50.00	\N	t	\N
d06d58ea-b1e2-4da8-b639-f64c21d58f97	d46a19da-37ec-4561-a3e6-0c4bf924feb7	2	8	50.00	\N	t	\N
33a4c10e-229a-44db-9b77-5457c3bebe9e	d46a19da-37ec-4561-a3e6-0c4bf924feb7	3	8	50.00	\N	t	\N
767be9c2-d2b5-486d-b2d0-ed0b609cf92b	d46a19da-37ec-4561-a3e6-0c4bf924feb7	4	8	40.00	\N	t	\N
765c5661-8130-4333-b4a5-ca49ecdee891	be0b5526-3910-4854-9b48-3b8b7e1617df	1	10	70.00	\N	t	\N
fbd43450-5239-431f-be84-5111a80d5b48	be0b5526-3910-4854-9b48-3b8b7e1617df	2	10	70.00	\N	t	\N
11464045-907d-412e-b19e-c315cc7519ff	be0b5526-3910-4854-9b48-3b8b7e1617df	3	10	70.00	\N	t	\N
064c1109-b14e-4261-ae47-7cbeda708e21	5085802b-dece-467c-96e4-7ac477f174d4	1	15	0.00	\N	t	\N
3157b5f0-b1bb-49f4-99cb-c8c81d949293	5085802b-dece-467c-96e4-7ac477f174d4	2	15	0.00	\N	t	\N
7def0b41-8132-493d-a34d-a99698b8e450	5085802b-dece-467c-96e4-7ac477f174d4	3	15	0.00	\N	t	\N
69c8d04f-5a98-45cc-ac1d-423c60797410	7ab945d0-fba7-4ffe-a780-28a3abe98e05	1	3	0.00	\N	t	\N
353b2f62-e50e-49ed-a86a-8164a19ecabc	e44c0f53-6d4a-4c6a-8ac4-fee407cbd854	1	4	34.00	\N	t	\N
e0967fd0-5f76-44fb-8407-a7a4d6c21103	e44c0f53-6d4a-4c6a-8ac4-fee407cbd854	2	6	32.00	\N	t	\N
ba3e0afc-ebb2-4c11-8915-531620520edb	e44c0f53-6d4a-4c6a-8ac4-fee407cbd854	3	6	32.00	\N	t	\N
9d0880d6-a4e3-4f67-a3f4-52e3c728f846	e44c0f53-6d4a-4c6a-8ac4-fee407cbd854	4	6	32.00	\N	t	\N
c7cbcc42-8df7-451b-9134-f5b8cef34d58	8b83e314-3958-4d55-bebf-feccc00a33c8	1	10	0.00	\N	t	\N
20687f66-28eb-4827-ac5f-f71d768d59f5	8b83e314-3958-4d55-bebf-feccc00a33c8	2	10	0.00	\N	t	\N
e08a0238-ce00-47ed-88a4-27a134788bc3	8b83e314-3958-4d55-bebf-feccc00a33c8	3	6	0.00	\N	t	\N
35daded6-8151-4b5e-a7c9-012ccf3450e8	8b83e314-3958-4d55-bebf-feccc00a33c8	4	8	0.00	\N	t	\N
fc57e91f-2a28-4d02-8b02-10ba734013c9	6e968d28-2c06-4a2d-b77c-3aa59c6e3631	1	8	20.00	\N	t	\N
c7e94b00-b5e0-471e-861b-d225d449f540	6e968d28-2c06-4a2d-b77c-3aa59c6e3631	2	8	20.00	\N	t	\N
f670f4e4-2a30-4fbd-b92f-e3243ec7799a	6e968d28-2c06-4a2d-b77c-3aa59c6e3631	3	8	20.00	\N	t	\N
66e31420-c9f6-430e-891c-5dfb82663a85	5e683c08-5b8f-4a3d-8874-3db7eaca70ae	1	8	0.00	\N	t	\N
063933c8-979b-4cb7-af2a-d7c10a34f43e	5e683c08-5b8f-4a3d-8874-3db7eaca70ae	2	8	0.00	\N	t	\N
c0373a36-0da6-4109-b88f-063a6ea966b3	5e683c08-5b8f-4a3d-8874-3db7eaca70ae	3	8	0.00	\N	t	\N
f7395a64-bb26-4794-b2bc-90582f326bee	d19fa4e8-d241-4734-82a5-36b03fa14dcd	1	15	22.50	\N	t	\N
0d505154-1a4d-4c13-a9f5-b487382f7fb9	d19fa4e8-d241-4734-82a5-36b03fa14dcd	2	15	22.50	\N	t	\N
8663fc4e-1621-400f-b4ac-e7376b38136a	d19fa4e8-d241-4734-82a5-36b03fa14dcd	3	15	22.50	\N	t	\N
a672dc19-1713-40bc-814d-47665ee6e799	b67ec874-2d05-484e-87c1-5cdd3815ca15	1	15	0.00	\N	t	\N
36d68817-bfde-4918-9b89-e68f54a3adec	b67ec874-2d05-484e-87c1-5cdd3815ca15	2	15	0.00	\N	t	\N
822ed54c-8d20-4bdd-bc1d-5b01462d5009	b67ec874-2d05-484e-87c1-5cdd3815ca15	3	15	0.00	\N	t	\N
2a5ed3cc-09d7-43ba-850b-3275b6184e8a	b5dcd876-7d64-44ec-8a4a-02c4751615c9	1	20	16.00	\N	t	\N
db1a0e47-8a0c-4b99-b39c-2c87eb56726b	b5dcd876-7d64-44ec-8a4a-02c4751615c9	2	20	16.00	\N	t	\N
7f5b7fbc-43c6-46c4-9251-ebf7505223d4	b5dcd876-7d64-44ec-8a4a-02c4751615c9	3	20	16.00	\N	t	\N
d5fb3e9a-7579-495f-929b-929e4c2eea51	fa77aa28-2b37-44b4-beb5-a0db18edcc7e	1	20	0.00	\N	t	\N
fcd2a7e1-ceb4-48e9-8efd-cc7a2c2888c4	fa77aa28-2b37-44b4-beb5-a0db18edcc7e	2	20	0.00	\N	t	\N
6b68e886-b290-4d3e-a83e-e15f55cda392	fa77aa28-2b37-44b4-beb5-a0db18edcc7e	3	20	0.00	\N	t	\N
187ae799-d598-44d7-ab04-69d1d63be364	6324c102-f803-4ad2-8b9d-4575cfc78648	1	6	80.00	\N	t	\N
9e91a31f-dfed-44a6-a9d5-9f52029b262e	6324c102-f803-4ad2-8b9d-4575cfc78648	2	6	80.00	\N	t	\N
06406819-2a1b-438d-ae7e-97cffc09b1ec	6324c102-f803-4ad2-8b9d-4575cfc78648	3	6	80.00	\N	t	\N
4d9fc7b1-0075-440b-8110-78db1adab8a4	6324c102-f803-4ad2-8b9d-4575cfc78648	4	6	80.00	\N	t	\N
51e7b63b-957c-4b3d-a458-469060e61488	798f7355-27d8-4584-bf54-77a9d7c386bf	1	10	70.00	\N	t	\N
ba4b3203-cb25-45bb-aaf2-daaf71b0da63	798f7355-27d8-4584-bf54-77a9d7c386bf	2	8	70.00	\N	t	\N
f49877c6-4781-448e-8777-a908a0eec508	798f7355-27d8-4584-bf54-77a9d7c386bf	3	10	70.00	\N	t	\N
490bb664-b308-4ddf-b464-7cf2c1fec276	aef9c7e6-51cb-4066-9152-a4424e277ed7	1	8	40.00	\N	t	\N
0a12f7cb-5845-469c-938d-2847ca7a4f4c	aef9c7e6-51cb-4066-9152-a4424e277ed7	2	8	40.00	\N	t	\N
3807802e-aa78-4a0e-9f5e-0170065be998	aef9c7e6-51cb-4066-9152-a4424e277ed7	3	8	40.00	\N	t	\N
9ae2e618-3804-4c9e-a5b1-1d7f0cc884e6	aef9c7e6-51cb-4066-9152-a4424e277ed7	4	8	40.00	\N	t	\N
217abaff-7186-40eb-a4bd-5eb34cc80c64	f62658bd-1aa8-45a6-a193-25fa5f516276	1	15	0.00	\N	t	\N
2fd7d615-d118-4181-b417-6314a2e84a4d	f62658bd-1aa8-45a6-a193-25fa5f516276	2	15	0.00	\N	t	\N
d1566fdd-c459-4c16-8768-81d2225ea050	f62658bd-1aa8-45a6-a193-25fa5f516276	3	15	0.00	\N	t	\N
9d9234b4-1b6d-4039-b4fa-ea0a27d8784e	2ec1edce-cf2d-4743-a1d4-fefc75867a25	1	6	32.00	\N	t	\N
92cd44bb-219f-4b99-8e5a-8a4fab0f08b5	2ec1edce-cf2d-4743-a1d4-fefc75867a25	2	6	32.00	\N	t	\N
8b1a34f9-ab7d-4860-ac04-ebd984acc256	2ec1edce-cf2d-4743-a1d4-fefc75867a25	3	6	32.00	\N	t	\N
70d8b7e5-0c22-45ef-8bea-34f6662ce0fa	2ec1edce-cf2d-4743-a1d4-fefc75867a25	4	5	32.00	\N	t	\N
1f9a4d13-705d-470c-96c3-6b06f0a24132	239f4a2c-f3a7-4ce9-8aff-485cc3bd1370	1	9	0.00	\N	t	\N
5a91a260-54a2-4ff5-84ad-a640b80a1b1b	239f4a2c-f3a7-4ce9-8aff-485cc3bd1370	2	10	0.00	\N	t	\N
ba44183a-8d43-418d-92d8-290aff50c3dc	239f4a2c-f3a7-4ce9-8aff-485cc3bd1370	3	9	0.00	\N	t	\N
a77b55a5-fc67-4a8b-b688-29db9b9bdd15	239f4a2c-f3a7-4ce9-8aff-485cc3bd1370	4	7	0.00	\N	t	\N
2447d1da-3bed-4279-bf8a-56f788008448	7e6a2eb7-ccb5-4881-9e50-9a05955716fb	1	8	15.00	\N	t	\N
c4cee80b-6585-4b95-8dc4-6d7ae3237229	7e6a2eb7-ccb5-4881-9e50-9a05955716fb	2	8	15.00	\N	t	\N
0ded6bd4-b7da-473c-a9c9-39727a6374dc	7e6a2eb7-ccb5-4881-9e50-9a05955716fb	3	7	15.00	\N	t	\N
a981fee2-01d3-4f20-8cd9-ede47ca0955e	8254be9c-9259-4ef7-9305-7f8eab88f587	1	7	8.00	\N	t	\N
b7b5a3a2-7254-4638-9ba2-8c75710497bc	8254be9c-9259-4ef7-9305-7f8eab88f587	2	5	16.00	\N	t	\N
ce22dc56-9fd9-42f8-a03e-7e06af0c94f1	8254be9c-9259-4ef7-9305-7f8eab88f587	3	5	16.00	\N	t	\N
28d043d4-f3b1-489c-b260-49a9a044eb1a	793851cf-b47b-4941-a0da-9c01fb8b85f3	1	15	16.25	\N	t	\N
14ba8029-c5e4-4992-b8da-686d95393ee5	793851cf-b47b-4941-a0da-9c01fb8b85f3	2	15	16.25	\N	t	\N
9e47393a-7321-4919-9f6f-11fc87b7f53d	793851cf-b47b-4941-a0da-9c01fb8b85f3	3	15	16.25	\N	t	\N
d49cf5a9-0bf9-4292-91f4-c3c1c0b22116	36ae5779-f43f-4a72-a6be-ce8435125b18	1	1	0.00	\N	t	\N
2ec5b403-1faa-4cf0-bb8c-8d7c3a955da4	36ae5779-f43f-4a72-a6be-ce8435125b18	2	1	0.00	\N	t	\N
8f5b1cf3-17f4-47f9-8d45-74aa56c292b4	36ae5779-f43f-4a72-a6be-ce8435125b18	3	1	0.00	\N	t	\N
4b54340d-fd05-4619-85a2-f231c172e749	f6311754-c404-41ab-a4dd-b1f5d3a9aa44	1	6	32.00	\N	t	\N
856e5343-d948-4836-8229-d36654beb2b9	f6311754-c404-41ab-a4dd-b1f5d3a9aa44	2	5	32.00	\N	t	\N
aabd2bf3-4508-46f6-93f7-ddcf3175f27d	f6311754-c404-41ab-a4dd-b1f5d3a9aa44	3	6	32.00	\N	t	\N
1e41d13a-c8a5-42e9-8a3c-129c8530f70e	f6311754-c404-41ab-a4dd-b1f5d3a9aa44	4	4	32.00	\N	t	\N
3bfcac43-7dcb-4e2b-8c7a-d6fa768501fd	d4cb0b31-108b-4a83-a783-922841f8a49c	1	10	0.00	\N	t	\N
1d3338a9-d1e3-4388-a1b3-34fe6339569c	d4cb0b31-108b-4a83-a783-922841f8a49c	2	10	0.00	\N	t	\N
2383f02e-666e-413d-9fbf-6e005202706a	d4cb0b31-108b-4a83-a783-922841f8a49c	3	10	0.00	\N	t	\N
c6ac5f26-9494-48a7-b49d-f67e23adf700	d4cb0b31-108b-4a83-a783-922841f8a49c	4	10	0.00	\N	t	\N
c8977f38-887b-469b-b431-378730cce85c	af34de3d-26e0-4e73-971a-9cb378a637ec	1	8	16.00	\N	t	\N
83b287e0-dd43-4300-8e32-916f7e7edb73	af34de3d-26e0-4e73-971a-9cb378a637ec	2	8	16.00	\N	t	\N
9b4f4536-06e3-4529-be72-ff09fcf57f93	af34de3d-26e0-4e73-971a-9cb378a637ec	3	8	16.00	\N	t	\N
fc5ef283-3014-4735-9c98-93fb74181e30	3e485eb0-ea92-45ea-9cfc-df8b1acedb6f	1	8	0.00	\N	t	\N
cb34ccb6-0fc4-4ed6-bccd-2783e0c637b7	3e485eb0-ea92-45ea-9cfc-df8b1acedb6f	2	8	0.00	\N	t	\N
9a1e6bf7-4531-4c9f-9af4-5f3d34bbccb7	3e485eb0-ea92-45ea-9cfc-df8b1acedb6f	3	8	0.00	\N	t	\N
86b32a01-5eec-42d6-9ad9-e9ae373df5aa	b2abd3f6-1cff-4496-a59b-f289aeedee8c	1	8	30.00	\N	t	\N
60d0a657-9217-4315-b307-c5cf6f11d7eb	b2abd3f6-1cff-4496-a59b-f289aeedee8c	2	8	30.00	\N	t	\N
c83a6274-8f42-4dcf-b34c-31e49e7b2330	b2abd3f6-1cff-4496-a59b-f289aeedee8c	3	8	30.00	\N	t	\N
1b817700-e76f-4e2c-b479-74a92c0fde30	c84570b2-237c-4a7e-ab0f-b62f575069a0	1	15	17.00	\N	t	\N
b9389a95-59b4-4dad-89ad-5bbc8d8849cf	c84570b2-237c-4a7e-ab0f-b62f575069a0	2	15	17.00	\N	t	\N
6521305b-d3eb-4528-9803-008ad959bd12	c84570b2-237c-4a7e-ab0f-b62f575069a0	3	15	17.00	\N	t	\N
c0e3caa2-1514-4f9e-a1f0-063d94b0c991	a72906f5-e0fe-4b7b-9ee2-432947c8691d	1	6	80.00	\N	t	\N
fbeb8ce8-ea76-4a7b-a42c-36d160476896	a72906f5-e0fe-4b7b-9ee2-432947c8691d	2	6	80.00	\N	t	\N
28143be0-071a-4612-87a4-8b849840aaed	a72906f5-e0fe-4b7b-9ee2-432947c8691d	3	6	80.00	\N	t	\N
24b87f1d-9111-49b4-8774-b53f5fab6e4d	a72906f5-e0fe-4b7b-9ee2-432947c8691d	4	6	80.00	\N	t	\N
0ffdaa62-d0b7-47b7-8892-69cc4f3ea542	bd7135f9-0e05-4b80-a114-de1c23988f68	1	10	70.00	\N	t	\N
6df80600-a1ba-421a-9a1f-0878f0b96d89	bd7135f9-0e05-4b80-a114-de1c23988f68	2	10	70.00	\N	t	\N
74216abc-5e4c-4591-a4f4-1acac8af0fd4	bd7135f9-0e05-4b80-a114-de1c23988f68	3	10	70.00	\N	t	\N
3aa8ebf7-f1ed-4511-82a8-73db1ffac0fc	2458fa1a-0546-431e-bc7e-d8859bde639a	1	8	16.00	\N	t	\N
89112474-043b-461b-9db3-4e63dee0debc	2458fa1a-0546-431e-bc7e-d8859bde639a	2	8	16.00	\N	t	\N
e281081c-6b0d-423b-9df8-ce46bbc90488	2458fa1a-0546-431e-bc7e-d8859bde639a	3	8	16.00	\N	t	\N
407f154a-4087-4f91-b48a-5b5a430504d1	020cc095-9f4e-4f3c-956a-fbd95abe1dc3	1	15	0.00	\N	t	\N
a9b84295-3813-4ea1-b7e6-edd9ae5d1450	020cc095-9f4e-4f3c-956a-fbd95abe1dc3	2	15	0.00	\N	t	\N
4c801b5b-4532-4d2d-9824-53212cbb8e5e	a62b34a6-9113-4eec-8486-717c72160317	1	50	32.00	\N	t	\N
1a14d970-0641-436e-b1f5-e7f4d849420d	a62b34a6-9113-4eec-8486-717c72160317	2	60	32.00	\N	t	\N
c3a0bde2-5ccd-44df-9a4c-d21e071b4af9	eae3e3a6-28b3-436b-ac8b-a6b50ce1c102	1	5	34.00	\N	t	\N
5a1ae89e-9c57-4014-8833-61a850730f9d	eae3e3a6-28b3-436b-ac8b-a6b50ce1c102	2	4	34.00	\N	t	\N
3bd26085-3c8f-4148-9357-100a8d131472	eae3e3a6-28b3-436b-ac8b-a6b50ce1c102	3	6	32.00	\N	t	\N
c1d9fdbb-3e65-4c59-a23f-4b2544ac51bd	eae3e3a6-28b3-436b-ac8b-a6b50ce1c102	4	4	32.00	\N	t	\N
8e71f247-3d87-4d97-b38e-d3c81d32b4b4	d71a608e-d92f-45ff-8927-c651c2f0542c	1	10	0.00	\N	t	\N
2160a210-2d09-4626-9c01-539f317b5262	d71a608e-d92f-45ff-8927-c651c2f0542c	2	10	0.00	\N	t	\N
9b5dae8a-81f6-4dfd-8636-d9d280f572a1	d71a608e-d92f-45ff-8927-c651c2f0542c	3	7	0.00	\N	t	\N
f702d398-de54-4293-afe8-799f1cc5ce4d	d71a608e-d92f-45ff-8927-c651c2f0542c	4	7	0.00	\N	t	\N
9bf1ca58-6d00-4352-ba22-ba46ad0f3fb4	4cc9a1b9-b2d9-4b12-b1b5-b2b5ecc70015	1	8	16.00	\N	t	\N
62eead9f-0569-4311-8697-3768b3c98750	4cc9a1b9-b2d9-4b12-b1b5-b2b5ecc70015	2	8	16.00	\N	t	\N
d1eca3eb-2d52-44b8-a081-50e717ec6750	4cc9a1b9-b2d9-4b12-b1b5-b2b5ecc70015	3	8	16.00	\N	t	\N
64bf3bcf-1283-4ae4-a2d0-e39117a8590f	d66a591e-976f-41ae-8297-e81a1e499ec7	1	10	0.00	\N	t	\N
97776a0a-05dc-475d-a760-29b7620c3084	56071e84-7636-4492-850b-5492b97bbff0	1	6	85.00	\N	t	\N
fc7f3dfd-c813-4dcc-99dc-4caebf64b2fd	56071e84-7636-4492-850b-5492b97bbff0	2	6	85.00	\N	t	\N
da88d5c4-78f1-4cf2-8dc8-7834344ed87d	56071e84-7636-4492-850b-5492b97bbff0	3	6	85.00	\N	t	\N
491b4f72-1215-4bdd-8926-8aedcb4c2996	56071e84-7636-4492-850b-5492b97bbff0	4	4	85.00	\N	t	\N
6befad44-715e-4867-8e94-9f2d070ac916	7a30ea29-9c66-4f38-bbea-38949feec451	1	8	75.00	\N	t	\N
43d9ee52-2d5d-4f7f-b941-5b9e679bb366	7a30ea29-9c66-4f38-bbea-38949feec451	2	8	75.00	\N	t	\N
35094866-a356-4606-8294-3405e21c91bd	7a30ea29-9c66-4f38-bbea-38949feec451	3	8	75.00	\N	t	\N
4738c025-9064-49b1-a37f-d5fe2c84396a	c7f9789a-22c6-4cbc-b2ca-0d168dadbe22	1	8	16.00	\N	t	\N
236d086b-a212-4d51-a203-aaa639ac7669	c7f9789a-22c6-4cbc-b2ca-0d168dadbe22	2	8	16.00	\N	t	\N
422ee0fe-c9e9-404e-abdc-106b37b3ee44	c7f9789a-22c6-4cbc-b2ca-0d168dadbe22	3	8	16.00	\N	t	\N
563f100f-4dbb-44d1-b530-b32259312e05	feffb16c-865b-4330-ab72-1cc546732207	1	60	32.00	\N	t	\N
e026c8c3-1589-4556-a4a0-200047cf653f	feffb16c-865b-4330-ab72-1cc546732207	2	60	48.00	\N	t	\N
3b33da9c-da3b-4801-a599-3c533acc52ca	ba892718-35e0-47e3-8f75-31aa42dc4b4e	1	18	0.00	\N	t	\N
8ae6cc00-5c19-4fd6-a005-a3e784c721f4	ba892718-35e0-47e3-8f75-31aa42dc4b4e	2	18	0.00	\N	t	\N
3f43f978-feda-491b-a55d-871cee0ac1ec	ba892718-35e0-47e3-8f75-31aa42dc4b4e	3	18	0.00	\N	t	\N
839ff6fb-a2c8-47f8-9213-1df1e8fbab25	f4c8cc69-cea9-46b2-bbda-503569eee6fa	1	5	34.00	\N	t	\N
318e5d5b-364b-45ea-a36e-ff17a354a1be	f4c8cc69-cea9-46b2-bbda-503569eee6fa	2	6	32.00	\N	t	\N
3512c933-112d-4940-afea-d1dc413bd48f	f4c8cc69-cea9-46b2-bbda-503569eee6fa	3	6	32.00	\N	t	\N
1ac0026a-bfc1-4d4c-a671-8b6be90d3110	f4c8cc69-cea9-46b2-bbda-503569eee6fa	4	6	32.00	\N	t	\N
5d3a8e5e-6a68-4130-8936-c921d573b97f	66083d28-b5ab-42a3-b5b1-ecd329db415b	1	10	0.00	\N	t	\N
bd828069-45f4-4cf2-a980-f962b9c9e6d0	66083d28-b5ab-42a3-b5b1-ecd329db415b	2	10	0.00	\N	t	\N
e24bb60e-0b0a-42a0-b3ac-a7990ebd192a	66083d28-b5ab-42a3-b5b1-ecd329db415b	3	10	0.00	\N	t	\N
34a468b0-9c88-473b-92ac-954209b0fb33	66083d28-b5ab-42a3-b5b1-ecd329db415b	4	7	0.00	\N	t	\N
10c0349d-97c5-443c-bbf9-ab655a092143	ca82590e-4626-4c36-9d4c-ae0db230d1d4	1	8	18.00	\N	t	\N
a2c1f6ba-3fbf-4f76-9230-552259d3305a	ca82590e-4626-4c36-9d4c-ae0db230d1d4	2	8	18.00	\N	t	\N
48b5c447-3f28-446e-a271-55117f6fef27	ca82590e-4626-4c36-9d4c-ae0db230d1d4	3	8	18.00	\N	t	\N
48562cbe-81db-4e19-87f2-6383f61c89a4	374a26a1-59cb-43a9-939b-5e5c318b09db	1	10	0.00	\N	t	\N
bca0dab6-d443-42d9-a46e-6e36011285e5	374a26a1-59cb-43a9-939b-5e5c318b09db	2	10	0.00	\N	t	\N
9a236f80-cc7c-4937-b011-e4e19fb9821e	374a26a1-59cb-43a9-939b-5e5c318b09db	3	10	0.00	\N	t	\N
b3f5cbf6-50e5-4d89-b60e-d77b320eb549	ad0ef543-b48a-4cbe-af9d-90778c042b34	1	8	30.00	\N	t	\N
dc5d0985-8363-456a-9453-2e3d8cae5f8f	ad0ef543-b48a-4cbe-af9d-90778c042b34	2	8	30.00	\N	t	\N
7af3274e-3692-48d1-a172-e874ca65c252	dbf27d78-2d5f-43c2-93cb-a12996b1084c	1	6	85.00	\N	t	\N
f146ee52-c6c7-4f10-b270-e9e50cf7d09a	dbf27d78-2d5f-43c2-93cb-a12996b1084c	2	6	85.00	\N	t	\N
c48599c6-ad46-4f89-be75-04ac2607ea58	dbf27d78-2d5f-43c2-93cb-a12996b1084c	3	6	85.00	\N	t	\N
a8ed957c-f67c-4ec2-9efb-8c697457bdc5	dbf27d78-2d5f-43c2-93cb-a12996b1084c	4	6	85.00	\N	t	\N
e6b0120e-8a52-49b4-9113-d119c40320b1	fe68684b-9b23-43ee-ba2e-fe54b38e8305	1	8	75.00	\N	t	\N
508df11f-b813-443d-9fd5-2418c7a25bd6	fe68684b-9b23-43ee-ba2e-fe54b38e8305	2	8	75.00	\N	t	\N
f0f7f386-6910-4acc-bdb1-30a23f420348	fe68684b-9b23-43ee-ba2e-fe54b38e8305	3	6	75.00	\N	t	\N
9db346c8-a573-4df0-944d-34994589cec2	814027a8-92ea-4a8e-b013-147be08b66bd	1	8	16.00	\N	t	\N
fa07f97d-2a37-41ce-bcad-5778831d4de6	814027a8-92ea-4a8e-b013-147be08b66bd	2	8	16.00	\N	t	\N
e930ad3d-f197-4286-a71a-90f6a114635e	578790a2-ce8e-4622-a0b7-e94ea382218b	1	60	32.00	\N	t	\N
8ad9607c-a152-4f00-b5d0-026fc185a6a2	578790a2-ce8e-4622-a0b7-e94ea382218b	2	60	48.00	\N	t	\N
e7122b8f-1607-4775-bc6a-80b7c33636a7	d5413358-2f06-4afd-87a8-bfeb3c74b4c3	1	18	0.00	\N	t	\N
096b98c1-7b45-4bba-b3df-20682ea52422	d5413358-2f06-4afd-87a8-bfeb3c74b4c3	2	18	0.00	\N	t	\N
4c20cff8-b09e-4458-8afc-b199964bd8ee	d5413358-2f06-4afd-87a8-bfeb3c74b4c3	3	18	0.00	\N	t	\N
515da936-3d33-4f2d-8197-d0cddff6250a	9493d235-f95b-4345-8b7e-a22d81d9398f	1	6	34.00	\N	t	\N
517a9ab8-e67d-436a-bd9b-2e6979f58ea1	9493d235-f95b-4345-8b7e-a22d81d9398f	2	5	34.00	\N	t	\N
24efb01b-c1e5-46ee-921e-0dce2e365643	9493d235-f95b-4345-8b7e-a22d81d9398f	3	6	32.00	\N	t	\N
3e4e742e-2b68-4124-b0d5-c93801833a5e	9493d235-f95b-4345-8b7e-a22d81d9398f	4	3	32.00	\N	t	\N
e35af2c2-14ca-419b-ba27-4e42f08381b0	8ed4f949-75a7-4b0c-bb84-b476979e1d29	1	10	0.00	\N	t	\N
537ee92b-6f41-4968-bfb1-429969d1c5cd	8ed4f949-75a7-4b0c-bb84-b476979e1d29	2	10	0.00	\N	t	\N
c55b78da-85a8-4b33-a490-0b58b6f8e1f2	8ed4f949-75a7-4b0c-bb84-b476979e1d29	3	8	0.00	\N	t	\N
c88db979-4906-4121-9cbf-da135dd203ac	8ed4f949-75a7-4b0c-bb84-b476979e1d29	4	6	0.00	\N	t	\N
321dce08-9f94-44f3-9886-1651a55cb0cd	51cf9550-ef19-490b-8e00-c6ca5218f39e	1	8	20.00	\N	t	\N
dbd1eeae-0fbc-4459-a6ad-56a9cfecd897	51cf9550-ef19-490b-8e00-c6ca5218f39e	2	7	20.00	\N	t	\N
693afbbf-3fe8-4e7f-960a-fbab70c2fc35	51cf9550-ef19-490b-8e00-c6ca5218f39e	3	5	20.00	\N	t	\N
4fbd0609-4eb6-48de-b989-623ccc2ea94b	4c470fc0-55c2-4f17-80ee-c879e1cf6de1	1	10	0.00	\N	t	\N
7a4ccf56-26c9-43ce-9be3-ca3a092eb67f	4c470fc0-55c2-4f17-80ee-c879e1cf6de1	2	6	16.00	\N	t	\N
8461aa39-4228-41cb-a723-afc918ed5ba7	4c470fc0-55c2-4f17-80ee-c879e1cf6de1	3	6	16.00	\N	t	\N
92c70b81-8117-425e-8b41-157695e2144a	00988256-d701-4519-9f55-c3c35a0f2f70	1	8	33.00	\N	t	\N
57b36704-0f23-4866-833e-31fba30c68f5	00988256-d701-4519-9f55-c3c35a0f2f70	2	8	33.00	\N	t	\N
2d42a7e6-336d-4e31-b433-ce2652058cd2	00988256-d701-4519-9f55-c3c35a0f2f70	3	8	33.00	\N	t	\N
5ca7a27d-e650-4e0d-a821-d899192f98c6	9a85ea56-7735-4496-a53b-91615a3d233c	1	6	34.00	\N	t	\N
e637fdea-493b-4b0b-b5cb-6402c1b23c79	9a85ea56-7735-4496-a53b-91615a3d233c	2	4	34.00	\N	t	\N
a57f0658-ce3c-4aad-a2e4-32ccfe38026d	9a85ea56-7735-4496-a53b-91615a3d233c	3	10	30.00	\N	t	\N
38783356-7fe4-4b0d-92bd-e44b9618d880	d12ef360-ee15-4725-8c77-7182f20630a6	1	10	0.00	\N	t	\N
7da5ae4c-8eec-48fd-9537-2aa2c3b421ae	d12ef360-ee15-4725-8c77-7182f20630a6	2	8	0.00	\N	t	\N
e1dfc2ea-d63c-42f1-b6c7-010f7a9b1f70	d12ef360-ee15-4725-8c77-7182f20630a6	3	8	0.00	\N	t	\N
3b0cbd4f-9001-4ad1-9394-ad7c0566f45d	bc6f4849-e18e-4eb1-9a93-b0ecd751704b	1	10	30.00	\N	t	\N
50a1b671-28ae-4823-bb34-cc931fc440e3	bc6f4849-e18e-4eb1-9a93-b0ecd751704b	2	10	30.00	\N	t	\N
76c8b600-5aa9-4e0e-94a7-cf972acd2b31	bc6f4849-e18e-4eb1-9a93-b0ecd751704b	3	8	30.00	\N	t	\N
1cdfe5df-8478-4a00-ab26-eb38820121c4	671b07dc-ea97-4f39-8e15-18fb7f22e433	1	8	12.00	\N	t	\N
f0f7769a-b347-4116-9535-af6eb0f6417f	671b07dc-ea97-4f39-8e15-18fb7f22e433	2	8	12.00	\N	t	\N
9058ca92-9cab-43b7-9a3a-2a05d38567fb	671b07dc-ea97-4f39-8e15-18fb7f22e433	3	8	12.00	\N	t	\N
ba99ffa6-6555-477c-a180-a01efd7b00e2	ad2f42d1-dfdf-4626-a775-1b09300db017	1	10	20.00	\N	t	\N
a629dc30-bc9c-4437-8b82-6307ea8ef2db	ad2f42d1-dfdf-4626-a775-1b09300db017	2	10	20.00	\N	t	\N
722b485e-3102-47df-a403-c827a5fbd304	ad2f42d1-dfdf-4626-a775-1b09300db017	3	10	20.00	\N	t	\N
55c89e1f-bb94-4d55-98a2-22357f1e1685	eb834825-1914-47e3-87fa-bb2811fa7d41	1	15	18.00	\N	t	\N
5c791696-74ad-4610-82ad-870c3bc20f34	eb834825-1914-47e3-87fa-bb2811fa7d41	2	15	18.00	\N	t	\N
621c50c0-700b-4ff3-8497-f57ff6862106	eb834825-1914-47e3-87fa-bb2811fa7d41	3	15	18.00	\N	t	\N
4023aa38-106a-46cc-b1cb-db3cf707ca32	e948d93d-17fe-4c9e-8480-517618cb3ff6	1	4	34.00	\N	t	\N
d8676df1-3042-45c5-874e-47cdc9067908	e948d93d-17fe-4c9e-8480-517618cb3ff6	2	4	32.00	\N	t	\N
87318fcb-aaef-49bf-9564-111f14c5685f	e948d93d-17fe-4c9e-8480-517618cb3ff6	3	5	32.00	\N	t	\N
5736a84d-5d0c-43ad-b4b3-6aa730edc33b	41fc7a96-7e68-44f0-8813-b17fe7acff9b	1	10	0.00	\N	t	\N
6d93308d-a732-4af8-afa6-1a6036120214	41fc7a96-7e68-44f0-8813-b17fe7acff9b	2	10	0.00	\N	t	\N
778619b2-3e81-4940-a32b-7304a4effd77	41fc7a96-7e68-44f0-8813-b17fe7acff9b	3	10	0.00	\N	t	\N
b6474717-f2f9-405c-8eee-59739fc3e2f6	ad766299-d735-4365-94d8-5603d1c54807	1	8	0.00	\N	t	\N
8d8c5122-4c3c-444a-9f08-3b378fe2fac2	ad766299-d735-4365-94d8-5603d1c54807	2	8	0.00	\N	t	\N
f681670e-4d18-4888-8ff6-c0f265f29b7d	ad766299-d735-4365-94d8-5603d1c54807	3	8	0.00	\N	t	\N
79bdc118-e2d8-4cb2-9174-69cc420cc21c	8f8032a3-a759-4080-b427-d0695eeb6206	1	10	20.00	\N	t	\N
604fafe1-b97c-45eb-89fb-db8fad6ff695	8f8032a3-a759-4080-b427-d0695eeb6206	2	10	20.00	\N	t	\N
66371508-1a21-4fee-acea-3ee3af40d7f6	8f8032a3-a759-4080-b427-d0695eeb6206	3	10	20.00	\N	t	\N
f00a212a-5114-4bf4-9800-055ef431c1f1	8dc1e82f-744d-4dbb-9c99-52fd08ef3b4c	1	5	34.00	\N	t	\N
d6d3087c-0488-46a7-9052-5cedbb499982	8dc1e82f-744d-4dbb-9c99-52fd08ef3b4c	2	6	32.00	\N	t	\N
3ac82563-11d8-4ce6-a5f8-b9a76ab3e729	8dc1e82f-744d-4dbb-9c99-52fd08ef3b4c	3	5	32.00	\N	t	\N
6fdba685-800a-453e-b33c-2a2df586739b	8dc1e82f-744d-4dbb-9c99-52fd08ef3b4c	4	\N	32.00	\N	t	\N
73ec713a-c65f-4f3a-81de-fb5acae44274	e8cb43e5-6c67-4414-839e-f947fec0380f	1	8	0.00	\N	t	\N
5c63051b-92b9-4c3c-938f-0ab58bd2a1e3	e8cb43e5-6c67-4414-839e-f947fec0380f	2	7	0.00	\N	t	\N
f4b45063-c866-4796-a8aa-e1c2d8ccd0f1	e8cb43e5-6c67-4414-839e-f947fec0380f	3	7	0.00	\N	t	\N
8dffee90-4906-4715-8b65-4f9cf24d60a0	e8cb43e5-6c67-4414-839e-f947fec0380f	4	7	0.00	\N	t	\N
25621678-0389-48e7-bf50-9a6a2560466e	18da4b42-f763-4b03-a7ff-5c622de5c0bd	1	\N	16.00	\N	t	\N
f649ffe3-2193-4303-9a6d-f331dfd7236d	18da4b42-f763-4b03-a7ff-5c622de5c0bd	2	\N	16.00	\N	t	\N
c35583b1-6cac-4af8-925b-f4fdb7201cf7	18da4b42-f763-4b03-a7ff-5c622de5c0bd	3	\N	16.00	\N	t	\N
d28c17d5-e5f1-40eb-a1de-75707a028fbc	b7ade734-f808-4e9f-91df-bcaf9d4be9e2	1	\N	30.00	\N	t	\N
ca23edba-0fd0-4a4b-9ed9-982a92cd4fa6	b7ade734-f808-4e9f-91df-bcaf9d4be9e2	2	\N	30.00	\N	t	\N
a8a56671-6108-4724-bbf7-0fb315e0ab5f	b7ade734-f808-4e9f-91df-bcaf9d4be9e2	3	\N	30.00	\N	t	\N
72792d60-be49-43e5-80ad-e4ece565a275	67c0879d-9424-4d22-a547-5527a003760b	1	15	18.75	\N	t	\N
d5f24e08-df4c-4f37-ab6a-68de8840ea7d	67c0879d-9424-4d22-a547-5527a003760b	2	\N	18.75	\N	t	\N
d2cef672-0fea-4369-83b7-318941438667	67c0879d-9424-4d22-a547-5527a003760b	3	\N	18.75	\N	t	\N
27afa1e3-a14f-4560-9526-841212de348a	67c0879d-9424-4d22-a547-5527a003760b	4	\N	18.75	\N	t	\N
496d634e-4e8d-4d50-b909-7ec36f347147	f76e06c2-5743-4029-9526-c81f5ef999e7	1	3	\N	\N	t	\N
906a39e5-8dec-479c-a5a3-b9bc03bee56e	f76e06c2-5743-4029-9526-c81f5ef999e7	2	3	\N	\N	t	\N
0e90ae05-e02b-4d85-93f6-56bfced7f099	f76e06c2-5743-4029-9526-c81f5ef999e7	3	3	\N	\N	t	\N
b02f6848-33a8-4ee5-8c76-9765f62a1f6d	fdeda02b-5f8b-4bd1-abb2-597717d9cc21	1	5	80.00	\N	t	3
15227456-cfc5-46e7-a427-49a08d7b6ea2	fdeda02b-5f8b-4bd1-abb2-597717d9cc21	2	5	80.00	\N	t	\N
1b9f8458-8162-44c6-8708-f485053ff39b	77476d0e-baab-4ac0-9daf-74eb3414ce5d	1	5	32.00	\N	t	0
5cd4c587-83d7-4e3f-aa6b-2bcd5b921975	77476d0e-baab-4ac0-9daf-74eb3414ce5d	2	5	32.00	\N	t	0
a5fa097f-1848-4190-9ac2-2d4de5d2b2fc	77476d0e-baab-4ac0-9daf-74eb3414ce5d	3	4	32.00	\N	t	0
0024a9fd-0c3c-49c6-975c-30ee88fc7679	34be82de-1c80-4c28-b3c4-47a8a85b8360	1	8	0.00	\N	t	0
678339ed-fe58-48e3-8379-512999070891	34be82de-1c80-4c28-b3c4-47a8a85b8360	2	7	0.00	\N	t	0
a3304aca-f245-4cdc-aeb5-4d7c0ec0a18c	34be82de-1c80-4c28-b3c4-47a8a85b8360	3	8	0.00	\N	t	0
2639e8cd-40eb-4fff-b984-85eea37ae65c	16e8951e-566b-4124-b91a-3f44a5fc6181	1	8	16.00	\N	t	2
080255a6-08f1-4df9-8100-4deab89685f9	16e8951e-566b-4124-b91a-3f44a5fc6181	2	8	16.00	\N	t	1
dc57357e-5b52-418c-9616-7b7ef070ba22	16e8951e-566b-4124-b91a-3f44a5fc6181	3	8	16.00	\N	t	0
46c30f60-0000-45aa-99b0-b86712919f4a	4e0262c4-4861-4c85-a571-bf3f4a62c7fa	1	20	\N	\N	t	\N
c38ec672-4b75-431f-9098-d04c720d1373	4e0262c4-4861-4c85-a571-bf3f4a62c7fa	2	20	\N	\N	t	\N
68c833b1-61fd-4ed0-8c0e-456e01eee36d	4e0262c4-4861-4c85-a571-bf3f4a62c7fa	3	20	\N	\N	t	\N
89bae8f6-4cc5-4a2d-8b06-35fc3074ce07	00e5954b-3dc3-4659-a7a4-64d963a3c1bd	1	8	\N	\N	t	\N
9c0808a3-cdc0-41c5-9279-0d5e0e5a7822	00e5954b-3dc3-4659-a7a4-64d963a3c1bd	2	8	\N	\N	t	\N
94618f2d-e2a4-4f92-a662-0bc32db62625	00e5954b-3dc3-4659-a7a4-64d963a3c1bd	3	8	\N	\N	t	\N
f750845b-becc-439d-95cc-464aa1cd1c35	ba31059d-b6fc-4cc2-9645-943f89397124	1	15	\N	\N	t	\N
0a9e8fd8-7c5a-4f49-9a2e-56bd9690c5b7	ba31059d-b6fc-4cc2-9645-943f89397124	2	15	\N	\N	t	\N
da5b270a-2b8c-4bf9-a4f9-97f3c7f23787	b8bfd97f-980a-421f-ba8a-32c37c463dce	1	6	32.00	\N	t	\N
8c203dd4-c9c4-4206-9147-7d428a55d64f	b8bfd97f-980a-421f-ba8a-32c37c463dce	2	5	32.00	\N	t	\N
74d774e5-261a-4cae-a204-9d6aee4be429	b8bfd97f-980a-421f-ba8a-32c37c463dce	3	6	32.00	\N	t	\N
aba511b5-2c2b-4901-bb48-0d58d7a63002	b779017f-082e-43d7-a656-5ad19f1c37a0	1	8	0.00	\N	t	\N
f408beb0-0de4-4127-a089-eeec81aec006	b779017f-082e-43d7-a656-5ad19f1c37a0	2	8	\N	\N	t	\N
4a26def2-de51-48ac-a627-6d8924d74a08	b779017f-082e-43d7-a656-5ad19f1c37a0	3	8	\N	\N	t	\N
49b89152-456e-4bfc-8597-b28482a44c41	021d8c25-2e61-4c54-9c34-ecac57f31fd1	1	10	30.00	\N	t	\N
976f082b-f217-4849-9edb-721aa0566e25	021d8c25-2e61-4c54-9c34-ecac57f31fd1	2	10	30.00	\N	t	\N
13f724cb-d39b-4955-a47d-7ec1d8e0e2a1	326dd201-df01-4557-b92e-8f130ff5ce70	1	12	20.00	\N	t	\N
c59e48d9-26ec-4d6d-814e-d7b4a9c8dd74	326dd201-df01-4557-b92e-8f130ff5ce70	2	11	20.00	\N	t	\N
aa07bbb5-db6f-4eb5-a230-4bd89070de0b	a9adcc0c-94d6-4a85-b8d2-f47dc419184f	1	10	30.00	\N	t	\N
283b3e52-9eb9-4467-94ae-94dc91647d64	a9adcc0c-94d6-4a85-b8d2-f47dc419184f	2	10	30.00	\N	t	\N
b310c374-f7a8-4b55-bd93-3e7ed85b44fb	a9adcc0c-94d6-4a85-b8d2-f47dc419184f	3	10	30.00	\N	t	\N
d067a25f-9034-4070-ac51-57f171575c54	45ea96db-e45c-4c8e-b833-d8e163318684	1	10	57.00	\N	t	\N
c17080ec-f6c5-4576-8c93-2744a14f684c	45ea96db-e45c-4c8e-b833-d8e163318684	2	10	57.00	\N	t	\N
2b7f699a-98dd-434f-a8eb-964b1310da6a	726fb72d-7e3a-4633-a004-81b09ee0260a	1	6	32.00	\N	t	\N
63a67c5d-f33f-442f-ba7a-67cb75a9e7ce	726fb72d-7e3a-4633-a004-81b09ee0260a	2	6	32.00	\N	t	\N
164d5b72-5fa0-4c2b-a403-d987345c7378	726fb72d-7e3a-4633-a004-81b09ee0260a	3	6	32.00	\N	t	\N
a6989257-ef44-4285-8595-70efe5148605	726fb72d-7e3a-4633-a004-81b09ee0260a	4	4	32.00	\N	t	\N
1dd398af-02ba-43d8-a7b7-1df991bb1e4b	76e4b7b6-b546-4a99-9493-72cb6ed61468	1	8	0.00	\N	t	\N
903a0874-29fc-43ec-9fdc-e022819f018b	76e4b7b6-b546-4a99-9493-72cb6ed61468	2	8	0.00	\N	t	\N
62804632-c332-4b73-a49d-80041f31ee33	76e4b7b6-b546-4a99-9493-72cb6ed61468	3	8	0.00	\N	t	\N
01d62141-acc1-4161-9020-83d212250936	76e4b7b6-b546-4a99-9493-72cb6ed61468	4	8	0.00	\N	t	\N
40b993a0-283e-47bd-a449-cb08e30a80a5	ea52b922-cfbf-4ee1-9b43-3815869e1bf5	1	10	17.50	\N	t	\N
f49038ad-6363-4e52-9edf-53b8e02464aa	ea52b922-cfbf-4ee1-9b43-3815869e1bf5	2	12	20.00	\N	t	\N
8f661e96-d205-415f-b328-c657296f6804	ea52b922-cfbf-4ee1-9b43-3815869e1bf5	3	12	20.00	\N	t	\N
7e5c924f-8e0c-4bac-b45e-219950d7145f	936464d1-8bb9-431b-991e-a94b7f18adf2	1	8	0.00	\N	t	\N
89a1709f-dcbf-40a5-b492-e9e9fbbdda32	936464d1-8bb9-431b-991e-a94b7f18adf2	2	8	\N	\N	t	\N
66a01166-5f16-4eaa-a09c-2874132e75b3	936464d1-8bb9-431b-991e-a94b7f18adf2	3	8	\N	\N	t	\N
e4c1755e-b095-4bcc-9e67-bca9f7da9680	93f7c3c9-95f3-4bf9-b5f0-19077e8c552c	1	\N	45.00	\N	f	\N
34597ee4-9ca4-4e08-87cf-35ee4e2d6632	93f7c3c9-95f3-4bf9-b5f0-19077e8c552c	2	\N	45.00	\N	f	\N
5ee754ea-cc7b-402c-8a74-67ec2e335b04	93f7c3c9-95f3-4bf9-b5f0-19077e8c552c	3	\N	45.00	\N	f	\N
c79810d0-2c36-4000-b951-3300aad72439	2f0e3a61-85e4-4a05-b503-f04b5dfd3ede	1	\N	17.00	\N	f	\N
f93df6a0-f0f0-493e-8513-12ba6edd28d4	2f0e3a61-85e4-4a05-b503-f04b5dfd3ede	2	\N	17.00	\N	f	\N
0d40f540-9fab-4f8e-958e-753fe9b6f57c	2f0e3a61-85e4-4a05-b503-f04b5dfd3ede	3	\N	17.00	\N	f	\N
1441c2c7-a566-4095-93f5-7f13d99e83ee	d1df13cd-8e9b-43b7-8db3-5dee0a872d13	1	3	\N	\N	t	\N
4e6cf00a-94b3-4877-b97c-5936dd6cee5b	d1df13cd-8e9b-43b7-8db3-5dee0a872d13	2	3	\N	\N	t	\N
ec954ba1-92f4-40b4-a731-b80ef6daffef	d1df13cd-8e9b-43b7-8db3-5dee0a872d13	3	3	\N	\N	t	\N
5ab79e45-71b4-41c2-9caa-4eeea7b41349	cb5db3c8-a12a-4627-9a1f-1b05219f8add	1	5	85.00	\N	t	2
508423fc-ee5d-4ab3-96a5-519db1ca4f20	cb5db3c8-a12a-4627-9a1f-1b05219f8add	2	5	85.00	\N	t	1
4a9ce837-c180-4a8c-99ea-89898c11809b	ee3925d9-79f2-4f35-b227-61ed7db0d25c	1	6	32.00	\N	t	1
194fe2a1-77d4-4150-8c17-98ced3ef563a	ee3925d9-79f2-4f35-b227-61ed7db0d25c	2	6	32.00	\N	t	0
017dd609-ca9b-4391-b909-1176bfc32f22	ee3925d9-79f2-4f35-b227-61ed7db0d25c	3	5	32.00	\N	t	0
139db53d-10c4-4a0c-a6e2-31f901ef0b2c	c2dc29fb-2d4e-4fef-9c70-efcb06f38bfd	1	8	\N	\N	t	\N
518726d9-aff4-421a-9595-a158aba6251c	c2dc29fb-2d4e-4fef-9c70-efcb06f38bfd	2	8	\N	\N	t	\N
cc2881aa-b7d8-4147-b458-427c9bd0fefe	c2dc29fb-2d4e-4fef-9c70-efcb06f38bfd	3	7	\N	\N	t	\N
6fab6d62-e36e-4bba-bbac-5bec25a1a039	eb89f2ec-8a58-4c92-afd0-d511fd80617c	1	8	16.00	\N	t	3
643f5a39-7f97-4716-94bc-337b1b8a5acc	eb89f2ec-8a58-4c92-afd0-d511fd80617c	2	8	16.00	\N	t	\N
29d76a09-69ce-418c-b53d-34ee52302bd7	eb89f2ec-8a58-4c92-afd0-d511fd80617c	3	8	16.00	\N	t	3
15190503-0dd0-4a31-b93b-7ced898582aa	d6760a3d-3429-46bc-88b1-3a02244f4c6e	1	20	\N	\N	t	\N
06a4e967-67bc-4c4d-a7e4-86e533e72995	d6760a3d-3429-46bc-88b1-3a02244f4c6e	2	20	\N	\N	t	\N
c9be5531-3e47-4830-b939-7e63e78aecc5	d6760a3d-3429-46bc-88b1-3a02244f4c6e	3	20	\N	\N	t	\N
ab8bf925-044d-43ce-aeb7-aff9bb2a02bf	5898dc9c-c93b-47bb-937c-8a5eb8c6bbea	1	8	\N	\N	t	\N
b9b712aa-722f-4c38-90e1-e4007b913ab9	5898dc9c-c93b-47bb-937c-8a5eb8c6bbea	2	8	\N	\N	t	\N
8274cc09-aba9-47a7-a4cc-5f77785a7047	5898dc9c-c93b-47bb-937c-8a5eb8c6bbea	3	8	\N	\N	t	\N
a0932a09-1c79-4a78-8519-4f991fd94c16	3872f2db-299c-482c-8ed8-ed7b067b5251	1	15	\N	\N	t	\N
1a260e49-ec25-46af-8294-6c49a014e22f	3872f2db-299c-482c-8ed8-ed7b067b5251	2	15	\N	\N	t	\N
26ce8fe1-a61d-4009-bec3-b6b9cfebd256	2b0553d3-905b-4d95-9661-ff9050c1929b	1	3	0.00	\N	t	\N
b177a635-403c-4d9c-9577-f0233b35b288	2b0553d3-905b-4d95-9661-ff9050c1929b	2	3	\N	\N	t	\N
275924d3-df6b-4525-ac24-802160120826	2b0553d3-905b-4d95-9661-ff9050c1929b	3	3	\N	\N	t	\N
8f269eee-91cd-4dfd-a3c0-080e2fa7c306	b58d7c4c-da74-42c4-88a8-ffcf38345be1	1	\N	82.50	\N	t	\N
6f10ae4f-ba88-4204-8b7d-611896c332d1	b58d7c4c-da74-42c4-88a8-ffcf38345be1	2	6	85.00	\N	t	0
02354283-b195-465a-8004-0d27bf6df1b7	9ae6ccce-66cc-4f0e-8c17-d4382cc399c5	1	6	32.00	\N	t	1
ef94fbfe-872e-4bde-bd29-d213211b1a15	9ae6ccce-66cc-4f0e-8c17-d4382cc399c5	2	6	32.00	\N	t	1
9681b725-968f-4f0a-99f5-81fa1176dd1d	9ae6ccce-66cc-4f0e-8c17-d4382cc399c5	3	7	32.00	\N	t	0
6eb6ab4d-ee5f-4028-9ccd-956a9c879269	f47cf19c-ca78-4e75-bb94-34478c8e9365	1	8	\N	\N	t	\N
d4f5ae22-7447-4be7-b65d-3a0d321bce2a	f47cf19c-ca78-4e75-bb94-34478c8e9365	2	8	\N	\N	t	\N
747f2d7f-2a0d-4ec3-b979-5646adcc97f5	f47cf19c-ca78-4e75-bb94-34478c8e9365	3	8	\N	\N	t	\N
e2cd2e5d-f579-4fbe-8cfb-b6179de6fa62	9b2aefa8-3c95-4fd8-9019-56473e2a84d2	1	\N	17.50	\N	f	\N
c990530a-a446-4c68-9bfd-9c2248b1fd56	9b2aefa8-3c95-4fd8-9019-56473e2a84d2	2	\N	17.50	\N	f	\N
0e5e885a-4246-44c4-afc6-69b186dc6a78	9b2aefa8-3c95-4fd8-9019-56473e2a84d2	3	\N	17.50	\N	f	\N
a28e0aa6-1909-45a4-9f1f-3416052b2c9c	3307d676-aa14-497f-8f4c-26ed7350ea43	1	20	\N	\N	t	\N
c64e2106-0905-4bc8-af02-46f4050b5cb6	3307d676-aa14-497f-8f4c-26ed7350ea43	2	20	\N	\N	t	\N
a3bfc755-7426-4d5f-b586-02e483babfda	3307d676-aa14-497f-8f4c-26ed7350ea43	3	20	\N	\N	t	\N
832357b2-39c2-4979-85ac-3fdbeed090d7	98cb8dea-a2c2-4cb9-b311-83aac1a8c031	1	8	\N	\N	t	\N
48c41752-5ac0-4a76-a80b-2522862a4135	98cb8dea-a2c2-4cb9-b311-83aac1a8c031	2	\N	\N	\N	f	\N
79aa9296-113f-4570-9679-9ef6e49ca11d	98cb8dea-a2c2-4cb9-b311-83aac1a8c031	3	\N	\N	\N	f	\N
b31b75f5-bf0d-402c-bd20-a8094a99ad53	843c68d6-4182-42ff-a984-77f76c197f4e	1	\N	\N	\N	f	\N
47f65511-f0f0-4a84-a91f-dac587f47b32	843c68d6-4182-42ff-a984-77f76c197f4e	2	\N	\N	\N	f	\N
\.


--
-- Data for Name: mesocycles; Type: TABLE DATA; Schema: public; Owner: coach
--

COPY public.mesocycles (id, user_id, name, goal, phase, start_date, end_date, weekly_structure, exercises, rules, warmup_protocol, is_active, created_at) FROM stdin;
23e074b0-7575-4ade-b7a6-5f10df8a3815	1add2a3d-727f-4607-aaad-759861f62394	Mesocycle 2 — Intensification	Build absolute strength and power through increased volume and intensity (3x8-10 reps). Enhance floorball-specific power and continue to improve right ankle stability, managing increased loading effectively.	intensification	2026-07-01	2026-07-28	{"fri": "floorball", "mon": "gym_upper", "sat": "active_recovery", "sun": "rest", "thu": "gym_lower", "tue": "rest", "wed": "floorball"}	{"gym_lower": {"D": {"name": "Farmers Carry", "note": "Core and grip strength. Focus on posture. Protects ankle by not having dynamic lateral movement.", "reps": 50, "sets": 3, "unit": "meters", "target_rpe": 7.5, "start_weight_kg": 45, "weekly_increment_kg": 2.5}, "A1": {"name": "Barbell Back Squat", "note": "Continuing progression. Focus on depth and control. Ankle stability cue: 'grip' the floor with your feet.", "reps": 8, "sets": 3, "target_rpe": 7.5, "start_weight_kg": 95, "weekly_increment_kg": 2.5}, "B1": {"name": "Romanian Deadlift (Barbell)", "note": "Hip hinge focus, Feel the stretch in hamstrings. Keep tight core. Protect lower back.", "reps": 8, "sets": 3, "target_rpe": 7.5, "start_weight_kg": 85, "weekly_increment_kg": 2.5}, "C1": {"name": "Bulgarian Split Squat (DB)", "note": "Excellent for unilateral strength and ankle stability. Progressing weight as stability improves. Start with light DBs to establish balance and depth. Progress slowly.", "reps": 10, "sets": 3, "target_rpe": 7.5, "start_weight_kg": 12.5, "weekly_increment_kg": 1.25}, "C2": {"name": "Calf Raises (Standing)", "note": "Full range of motion, controlled eccentric. Strengthens ankle joint indirectly.", "reps": 15, "sets": 3, "target_rpe": 8, "start_weight_kg": 35, "weekly_increment_kg": 2.5}}, "gym_upper": {"A1": {"name": "DB Bench Press", "note": "Building on previous progression. Focus on 8 clean reps per set. Once 3x8 is hit for 2 sessions, progress weight.", "reps": 8, "sets": 3, "target_rpe": 7.5, "start_weight_kg": 39, "weekly_increment_kg": 1.25}, "B1": {"name": "Weighted Pull-ups", "note": "Starting with a more significant external load to drive strength. Aim for 6 clean reps. Progress 1.25kg/week.", "reps": 6, "sets": 3, "target_rpe": 7.5, "start_weight_kg": 10, "weekly_increment_kg": 1.25}, "B2": {"name": "DB Overhead Press (Standing)", "note": "Standing for core stability. Strict form. Building intensity.", "reps": 8, "sets": 3, "target_rpe": 7.5, "start_weight_kg": 23, "weekly_increment_kg": 1}, "C1": {"name": "Weighted Dips", "note": "Aim for 8 reps. Adjust weight to stay in RPE range.", "reps": 8, "sets": 3, "target_rpe": 7.5, "start_weight_kg": 20, "weekly_increment_kg": 1.25}, "C2": {"name": "Chest-Supported T-Bar Row", "note": "Higher reps for back volume. Focus on controlled eccentric.", "reps": 10, "sets": 3, "target_rpe": 7.5, "start_weight_kg": 50, "weekly_increment_kg": 2.5}, "C3": {"name": "Face Pulls (Cable)", "note": "Maintain shoulder health, high reps. Use correct form (pull to face).", "reps": 15, "sets": 3, "target_rpe": 7.5, "start_weight_kg": 26, "weekly_increment_kg": 1.25}}}	{"backfill_after_miss": false, "progression_trigger": "all_sets_completed_as_planned", "missed_session_action": "skip_progression_for_that_session", "regression_trigger_rpe": 9, "regression_trigger_consecutive_rpe": 2}	{"note": "Band pull-aparts for shoulder health. Dedicated ankle mobility for prehab, especially before lower body and floorball.", "gym_sessions": ["Band Pull-Aparts 3x20 (light)", "Dynamic Ankle Carries 2-3 min (multi-directional, controlled)"]}	f	2026-07-10 06:49:22.254043
89b32562-1525-4cbb-8df0-89d31fc2cd9b	1add2a3d-727f-4607-aaad-759861f62394	Mesocycle 3 — Accumulation	Build general strength and work capacity, with a focus on single-leg and core stability for floorball. Introduce more specific movements.	accumulation	2026-07-14	2026-08-10	{"fri": "team_training", "mon": "team_training", "sat": "active_recovery", "sun": "rest", "thu": "gym_session_2", "tue": "gym_session_1", "wed": "morning_routine"}	{}	{"progression_trigger": "all_sets_completed_as_planned", "regression_trigger_rpe": 9}	{"note": "Focus on preparing the body for the specific movements of the session.", "gym_sessions": ["5-10 min light cardio (bike/rower)", "Dynamic stretches (leg swings, arm circles, torso twists)", "Specific warm-up sets for main lifts (2-3 sets of increasing weight, lower reps)"]}	f	2026-07-13 12:11:12.580235
570bf696-fe9d-4867-9516-d2f3cb22e480	1add2a3d-727f-4607-aaad-759861f62394	Mesocycle 3 — Accumulation	Build general strength and work capacity with a focus on unilateral leg strength and core stability, preparing for the upcoming season.	accumulation	2026-07-14	2026-08-10	{"fri": "team_training", "mon": "team_training", "sat": "active_recovery", "sun": "rest", "thu": "gym_session_2", "tue": "gym_session_1", "wed": "morning_routine"}	{"gym_session_1": {"A1": {"name": "Barbell Back Squat", "note": "Focus on controlled eccentric and driving up powerfully. Maintain good depth. Keep core braced.", "reps": 8, "sets": 4, "target_rpe": 7, "start_weight_kg": 90, "weekly_increment_kg": 2.5}, "B1": {"name": "Single-Leg Romanian Deadlift (DB)", "note": "Emphasize hip hinge and balance. Keep a slight bend in the standing knee. Control the descent. Excellent for hamstring and glute strength, and ankle stability.", "reps": 8, "sets": 3, "target_rpe": 7, "start_weight_kg": 15, "weekly_increment_kg": 1.25}, "C1": {"name": "Copenhagen Plank", "note": "Focus on hip adductor strength and core stability. Start with bodyweight, progress to holding for longer or adding light weight if too easy.", "reps": "30-45s hold", "sets": 3, "target_rpe": 8, "start_weight_kg": 0, "weekly_increment_kg": 0}, "C2": {"name": "Pallof Press (Cable)", "note": "Anti-rotation core exercise. Keep hips and shoulders square. Control the movement both ways.", "reps": 10, "sets": 3, "target_rpe": 7, "start_weight_kg": 15, "weekly_increment_kg": 1.25}, "D1": {"name": "Standing Calf Raises (DB)", "note": "Full range of motion, controlled eccentric. Hold a dumbbell in one hand for added resistance.", "reps": 12, "sets": 3, "target_rpe": 7.5, "start_weight_kg": 20, "weekly_increment_kg": 1.25}}, "gym_session_2": {"A1": {"name": "DB Bench Press", "note": "Focus on controlled movement and full range of motion. Maintain shoulder stability.", "reps": 8, "sets": 4, "target_rpe": 7, "start_weight_kg": 32.5, "weekly_increment_kg": 1.25}, "B1": {"name": "Weighted Pull-ups", "note": "Aim for clean reps. If unable to hit reps with weight, switch to bodyweight or assisted. Focus on pulling with the back muscles.", "reps": 6, "sets": 3, "target_rpe": 7.5, "start_weight_kg": 5, "weekly_increment_kg": 1.25}, "B2": {"name": "DB Overhead Press (Seated)", "note": "Seated to isolate shoulders and reduce lower back involvement. Control the weight up and down.", "reps": 8, "sets": 3, "target_rpe": 7, "start_weight_kg": 20, "weekly_increment_kg": 1}, "C1": {"name": "Bent-Over Barbell Row", "note": "Maintain a flat back and engage the lats. Pull towards the lower abdomen. Controlled eccentric.", "reps": 10, "sets": 3, "target_rpe": 7, "start_weight_kg": 40, "weekly_increment_kg": 2.5}, "C2": {"name": "Woodchoppers (Cable)", "note": "Rotational core strength. Control the movement, don't let the weight pull you. Focus on oblique engagement.", "reps": 10, "sets": 3, "target_rpe": 7.5, "start_weight_kg": 15, "weekly_increment_kg": 1.25}, "D1": {"name": "Face Pulls (Cable)", "note": "High reps for shoulder health and rear deltoid development. Pull to face, externally rotate.", "reps": 15, "sets": 3, "target_rpe": 7, "start_weight_kg": 20, "weekly_increment_kg": 1.25}}, "morning_routine": {"A1": {"name": "Tibialis Raises", "note": "Focus on controlled movement. Can be done standing against a wall or with a resistance band.", "reps": 15, "sets": 3, "target_rpe": 7, "start_weight_kg": 0, "weekly_increment_kg": 0}, "B1": {"name": "ATG Split Squat", "note": "Deep lunge with front knee over toes. Focus on ankle mobility and quad stretch. Use support if needed for balance.", "reps": 8, "sets": 3, "target_rpe": 6, "start_weight_kg": 0, "weekly_increment_kg": 0}, "C1": {"name": "Couch Stretch", "note": "Hold for 60 seconds per side. Focus on hip flexor and quad stretch. Maintain an upright torso.", "reps": "60s hold", "sets": 2, "target_rpe": 6, "start_weight_kg": 0, "weekly_increment_kg": 0}, "D1": {"name": "Bird-Dog", "note": "Core stability and coordination. Keep spine neutral, avoid rocking hips.", "reps": 10, "sets": 3, "target_rpe": 5, "start_weight_kg": 0, "weekly_increment_kg": 0}, "E1": {"name": "Thoracic Rotations (Seated)", "note": "Improve upper back mobility. Gentle, controlled rotations.", "reps": 10, "sets": 2, "target_rpe": 5, "start_weight_kg": 0, "weekly_increment_kg": 0}}}	{"progression_trigger": "all_sets_completed_as_planned", "regression_trigger_rpe": 9}	{"note": "Focus on preparing the body for the specific movements of the session.", "gym_sessions": ["5-10 min light cardio (bike/rower)", "Dynamic stretches (leg swings, arm circles, torso twists)", "Specific warm-up sets for main lifts (2-3 sets of increasing weight, lower reps)"]}	t	2026-07-13 12:59:09.175232
f8d438e6-2a6a-4088-aeeb-3316d8780f0f	1add2a3d-727f-4607-aaad-759861f62394	Mesocycle 1 — Intensification	Build strength for the upcoming season, focusing on compound movements and single-leg work, while maintaining mobility and injury prevention.	intensification	2026-07-14	2026-08-10	{"fri": "floorball_team_training", "mon": "floorball_team_training", "sat": "gym_session_2", "sun": "rest", "thu": "rest", "tue": "gym_session_1", "wed": "morning_routine"}	{}	{"progression_trigger": "all_sets_completed_as_planned_for_2_sessions", "regression_trigger_rpe": 9}	{"note": "Focus on feeling prepared for the work ahead, not fatigued.", "gym_sessions": ["5-10 minutes light cardio (bike/rower)", "Dynamic stretches (leg swings, arm circles, torso twists)", "Specific warm-up sets for main lifts (2-3 sets of increasing weight, decreasing reps)"]}	f	2026-07-13 12:44:20.297104
\.


--
-- Data for Name: personal_records; Type: TABLE DATA; Schema: public; Owner: coach
--

COPY public.personal_records (id, user_id, exercise_name, weight, reps, e1rm, achieved_at) FROM stdin;
aeafa0f4-e6a2-4e83-b033-1581090df30b	1add2a3d-727f-4607-aaad-759861f62394	Split Squat	16.00	8	20.27	2026-07-26
cbe53e94-89c7-4f2d-936c-974e6c7b42ff	1add2a3d-727f-4607-aaad-759861f62394	Back Squat	85.00	6	102.00	2026-08-04
7a66c2bf-43a7-4108-b272-9e247a8800e6	1add2a3d-727f-4607-aaad-759861f62394	DB Bench Press	32.00	7	39.47	2026-08-04
\.


--
-- Data for Name: session_templates; Type: TABLE DATA; Schema: public; Owner: coach
--

COPY public.session_templates (id, user_id, name, exercises, is_active, mesocycle_id, created_at, updated_at) FROM stdin;
35762315-0aea-48c3-8104-d294f888ced3	1add2a3d-727f-4607-aaad-759861f62394	Morning Routine	[{"name": "Tibialis Raises", "reps": "15", "sets": 3, "notes": "Focus on controlled movement. Can be done standing against a wall or with a resistance band."}, {"name": "ATG Split Squat", "reps": "8", "sets": 3, "notes": "Deep lunge with front knee over toes. Focus on ankle mobility and quad stretch. Use support if needed for balance."}, {"name": "Copenhagen Hold", "reps": "8", "sets": 3}, {"name": "Calf Raises auf Stufe", "reps": "8", "sets": 3}]	t	570bf696-fe9d-4867-9516-d2f3cb22e480	2026-07-13 12:59:09.185826	2026-07-16 13:33:00.671
0b484ad3-f17f-4a80-82a4-823ed7e1e6f5	1add2a3d-727f-4607-aaad-759861f62394	test	[]	f	\N	2026-07-13 12:57:39.012927	2026-07-13 12:57:40.46
3168afe7-fe9d-42eb-b65e-68ef2d0ea3f3	1add2a3d-727f-4607-aaad-759861f62394	Lower Body	[{"name": "Farmers Carry", "reps": "50", "sets": 3, "notes": "Core and grip strength. Focus on posture. Protects ankle by not having dynamic lateral movement."}, {"name": "Barbell Back Squat", "reps": "8", "sets": 3, "notes": "Continuing progression. Focus on depth and control. Ankle stability cue: 'grip' the floor with your feet."}, {"name": "Romanian Deadlift (Barbell)", "reps": "8", "sets": 3, "notes": "Hip hinge focus, Feel the stretch in hamstrings. Keep tight core. Protect lower back."}, {"name": "Bulgarian Split Squat (DB)", "reps": "10", "sets": 3, "notes": "Excellent for unilateral strength and ankle stability. Progressing weight as stability improves. Start with light DBs to establish balance and depth. Progress slowly."}, {"name": "Calf Raises (Standing)", "reps": "15", "sets": 3, "notes": "Full range of motion, controlled eccentric. Strengthens ankle joint indirectly."}]	f	23e074b0-7575-4ade-b7a6-5f10df8a3815	2026-07-13 12:56:35.949117	2026-07-13 12:56:35.949117
367c3db0-441d-4eeb-9e05-0edb59a16963	1add2a3d-727f-4607-aaad-759861f62394	Upper Body	[{"name": "DB Bench Press", "reps": "8", "sets": 3, "notes": "Building on previous progression. Focus on 8 clean reps per set. Once 3x8 is hit for 2 sessions, progress weight."}, {"name": "Weighted Pull-ups", "reps": "6", "sets": 3, "notes": "Starting with a more significant external load to drive strength. Aim for 6 clean reps. Progress 1.25kg/week."}, {"name": "DB Overhead Press (Standing)", "reps": "8", "sets": 3, "notes": "Standing for core stability. Strict form. Building intensity."}, {"name": "Weighted Dips", "reps": "8", "sets": 3, "notes": "Aim for 8 reps. Adjust weight to stay in RPE range."}, {"name": "Chest-Supported T-Bar Row", "reps": "10", "sets": 3, "notes": "Higher reps for back volume. Focus on controlled eccentric."}, {"name": "Face Pulls (Cable)", "reps": "15", "sets": 3, "notes": "Maintain shoulder health, high reps. Use correct form (pull to face)."}]	f	23e074b0-7575-4ade-b7a6-5f10df8a3815	2026-07-13 12:56:35.951321	2026-07-13 12:56:35.951321
dadc2ecb-4cf8-482b-ae0c-537a1e4169b2	1add2a3d-727f-4607-aaad-759861f62394	Gym Session 1	[{"name": "Coutermovement Jump", "reps": "3", "sets": 3}, {"name": "Back Squat", "reps": "5", "sets": 2}, {"name": "DB Bench Press", "reps": "6", "sets": 3, "notes": "Focus on controlled movement and full range of motion. Maintain shoulder stability."}, {"name": "Pull-ups (Bodyweight)", "reps": "8", "sets": 3}, {"name": "Split Squat", "reps": "8", "sets": 3}, {"name": "Copenhagen Plank", "reps": "20", "sets": 3}, {"name": "Pallof Press 2 sec Hold", "reps": "8", "sets": 3}, {"name": "Tibialis Raises", "reps": "15", "sets": 2}]	t	570bf696-fe9d-4867-9516-d2f3cb22e480	2026-07-13 12:59:09.184044	2026-07-16 13:24:53
e063b713-4069-49f0-a4da-b1d0c50e2e52	1add2a3d-727f-4607-aaad-759861f62394	Gym Session 2	[{"name": "Skater Hop", "reps": "3", "sets": 3}, {"name": "Woodchoppers", "reps": "8", "sets": 4}, {"name": "Romanian Deadlift", "reps": "6", "sets": 2}, {"name": "Single-Leg RDL", "reps": "8", "sets": 2}, {"name": "Bench Press Dumbbells", "reps": "6", "sets": 3}, {"name": "Pull-ups (Bodyweight)", "reps": "8", "sets": 3}, {"name": "ATG Split Squat", "reps": "8", "sets": 3}, {"name": "Face Pulls (Cable)", "reps": "12", "sets": 3}]	t	570bf696-fe9d-4867-9516-d2f3cb22e480	2026-07-13 12:59:09.181611	2026-07-16 13:29:41.603
\.


--
-- Data for Name: user_settings; Type: TABLE DATA; Schema: public; Owner: coach
--

COPY public.user_settings (id, user_id, situation_prompt, rest_timer_default, ai_enabled, updated_at, ai_mesocycle_enabled, ai_session_analysis_enabled, ai_briefing_enabled, ai_substitution_enabled, ai_deload_detection_enabled) FROM stdin;
c4634201-59bd-4caf-b391-ab0d12c72990	1add2a3d-727f-4607-aaad-759861f62394	I'm a floorball player in off-season. I want a split for gym training 2× per week. Prefer single-leg work. My main goal is building strength for the season starting in September. I have training sessions with the team on Monday and Friday where we do some strength and interval exercises. The two gym sessions are therefore not the only strength activity. The templates should contain two Gym-Sessions and one Morning routine. The mornign routine should contain mobility and prevention exercises like Tibialis Raises, ATG Split Squats and Couch Stretch. The Gym-Sessions should contain a mix of general strength exercises for chest, back, arms, shoulders, legs and so on as well as more specific exercises like Copenhagen Planks, Woodchoppers and Palloff Press.	120	t	2026-07-13 12:10:52.443	t	t	f	t	f
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: coach
--

COPY public.users (id, email, name, password_hash, email_verified, image, created_at, updated_at, is_admin) FROM stdin;
1add2a3d-727f-4607-aaad-759861f62394	sacha.aebischer@gmail.com	Sacha	$2b$12$0aC1t7IiacZReZVCl9JUC.zYuU6ksJ196WvEXcM5DGnUHLWnJUtVO	\N	\N	2026-07-10 06:49:22.247183	2026-07-10 06:49:22.247183	t
\.


--
-- Data for Name: verification_tokens; Type: TABLE DATA; Schema: public; Owner: coach
--

COPY public.verification_tokens (identifier, token, expires) FROM stdin;
\.


--
-- Data for Name: weekly_ai_summaries; Type: TABLE DATA; Schema: public; Owner: coach
--

COPY public.weekly_ai_summaries (id, user_id, week_start, summary, created_at) FROM stdin;
\.


--
-- Data for Name: weight_overrides; Type: TABLE DATA; Schema: public; Owner: coach
--

COPY public.weight_overrides (id, user_id, exercise_name, next_weight_kg, reason, from_session_date, updated_at) FROM stdin;
ed92179a-69cf-4018-918a-22c0791eb28c	1add2a3d-727f-4607-aaad-759861f62394	Bench Press Dumbbells	32.00	Performance was consistent with previous sessions at this weight, but without RPE, it's safer to maintain. The target for DB Bench Press (from mesocycle) is 3x8, so 3x6,5,6 is not yet hitting the target.	2026-07-07	2026-08-04 15:38:41.987
a670b144-265b-4d05-a3b3-5af32483b488	1add2a3d-727f-4607-aaad-759861f62394	Lateral Raises Machine	30.00	Consistent performance for 2 sets. Without a target or RPE, maintaining is the conservative approach.	2026-07-07	2026-08-04 15:38:41.989
2844cbab-7a94-4ffd-b17b-613d4a21c278	1add2a3d-727f-4607-aaad-759861f62394	Shoulder Press Machine	20.00	Good performance with 12 and 11 reps. The mesocycle has 'DB Overhead Press (Standing)' as a different exercise. Maintaining current weight due to lack of RPE and specific target for this machine exercise.	2026-07-07	2026-08-04 15:38:41.99
2cf3e85b-283f-4b8e-8615-5037f76357c1	1add2a3d-727f-4607-aaad-759861f62394	Triceps Overhead	30.00	Consistent performance across all sets. Without a target or RPE, maintaining is appropriate.	2026-07-07	2026-08-04 15:38:41.991
b84c06dc-e0eb-4cdb-bebe-9a00e00e6719	1add2a3d-727f-4607-aaad-759861f62394	Butterfly	57.00	Consistent performance for 2 sets. Without a target or RPE, maintaining is the conservative approach.	2026-07-07	2026-08-04 15:38:41.991
ffb89b36-ce94-41f9-a5d0-b54fcd1c16c6	1add2a3d-727f-4607-aaad-759861f62394	DB Bench Press	32.00	All target reps were completed, with the last set exceeding the target but at a very high RPE. While technically a success, the high RPE suggests maintaining the weight to solidify performance before increasing.	2026-08-04	2026-08-04 15:38:41.992
b275661d-33be-4f78-b6de-c9d5a19e165c	1add2a3d-727f-4607-aaad-759861f62394	Back Squat	80.00	The last set was performed at RPE 10 (0 RIR) and exceeded the target reps, indicating a potential overestimation of RPE or a very hard effort. Given the RPE, a slight regression is warranted to ensure quality and stay within the target RPE range for the mesocycle.	2026-08-04	2026-08-04 15:38:41.993
fa914d6e-3180-4c50-8a2f-4a599bfb5601	1add2a3d-727f-4607-aaad-759861f62394	Split Squat	17.50	All sets completed for target reps, though RIR decreased significantly towards the end, indicating high effort. A small increase is warranted given the successful completion.	2026-07-26	2026-08-04 15:38:41.994
\.


--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE SET; Schema: drizzle; Owner: coach
--

SELECT pg_catalog.setval('drizzle.__drizzle_migrations_id_seq', 2, true);


--
-- Name: __drizzle_migrations __drizzle_migrations_pkey; Type: CONSTRAINT; Schema: drizzle; Owner: coach
--

ALTER TABLE ONLY drizzle.__drizzle_migrations
    ADD CONSTRAINT __drizzle_migrations_pkey PRIMARY KEY (id);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: coach
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: ai_analyses ai_analyses_pkey; Type: CONSTRAINT; Schema: public; Owner: coach
--

ALTER TABLE ONLY public.ai_analyses
    ADD CONSTRAINT ai_analyses_pkey PRIMARY KEY (id);


--
-- Name: ai_briefings ai_briefings_pkey; Type: CONSTRAINT; Schema: public; Owner: coach
--

ALTER TABLE ONLY public.ai_briefings
    ADD CONSTRAINT ai_briefings_pkey PRIMARY KEY (id);


--
-- Name: auth_sessions auth_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: coach
--

ALTER TABLE ONLY public.auth_sessions
    ADD CONSTRAINT auth_sessions_pkey PRIMARY KEY (id);


--
-- Name: auth_sessions auth_sessions_session_token_unique; Type: CONSTRAINT; Schema: public; Owner: coach
--

ALTER TABLE ONLY public.auth_sessions
    ADD CONSTRAINT auth_sessions_session_token_unique UNIQUE (session_token);


--
-- Name: body_weight_log body_weight_log_pkey; Type: CONSTRAINT; Schema: public; Owner: coach
--

ALTER TABLE ONLY public.body_weight_log
    ADD CONSTRAINT body_weight_log_pkey PRIMARY KEY (id);


--
-- Name: exercise_catalog exercise_catalog_pkey; Type: CONSTRAINT; Schema: public; Owner: coach
--

ALTER TABLE ONLY public.exercise_catalog
    ADD CONSTRAINT exercise_catalog_pkey PRIMARY KEY (id);


--
-- Name: gym_exercises gym_exercises_pkey; Type: CONSTRAINT; Schema: public; Owner: coach
--

ALTER TABLE ONLY public.gym_exercises
    ADD CONSTRAINT gym_exercises_pkey PRIMARY KEY (id);


--
-- Name: gym_sessions gym_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: coach
--

ALTER TABLE ONLY public.gym_sessions
    ADD CONSTRAINT gym_sessions_pkey PRIMARY KEY (id);


--
-- Name: gym_sets gym_sets_pkey; Type: CONSTRAINT; Schema: public; Owner: coach
--

ALTER TABLE ONLY public.gym_sets
    ADD CONSTRAINT gym_sets_pkey PRIMARY KEY (id);


--
-- Name: mesocycles mesocycles_pkey; Type: CONSTRAINT; Schema: public; Owner: coach
--

ALTER TABLE ONLY public.mesocycles
    ADD CONSTRAINT mesocycles_pkey PRIMARY KEY (id);


--
-- Name: personal_records personal_records_pkey; Type: CONSTRAINT; Schema: public; Owner: coach
--

ALTER TABLE ONLY public.personal_records
    ADD CONSTRAINT personal_records_pkey PRIMARY KEY (id);


--
-- Name: session_templates session_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: coach
--

ALTER TABLE ONLY public.session_templates
    ADD CONSTRAINT session_templates_pkey PRIMARY KEY (id);


--
-- Name: user_settings user_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: coach
--

ALTER TABLE ONLY public.user_settings
    ADD CONSTRAINT user_settings_pkey PRIMARY KEY (id);


--
-- Name: user_settings user_settings_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: coach
--

ALTER TABLE ONLY public.user_settings
    ADD CONSTRAINT user_settings_user_id_unique UNIQUE (user_id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: coach
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: coach
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: verification_tokens verification_tokens_token_unique; Type: CONSTRAINT; Schema: public; Owner: coach
--

ALTER TABLE ONLY public.verification_tokens
    ADD CONSTRAINT verification_tokens_token_unique UNIQUE (token);


--
-- Name: weekly_ai_summaries weekly_ai_summaries_pkey; Type: CONSTRAINT; Schema: public; Owner: coach
--

ALTER TABLE ONLY public.weekly_ai_summaries
    ADD CONSTRAINT weekly_ai_summaries_pkey PRIMARY KEY (id);


--
-- Name: weight_overrides weight_overrides_pkey; Type: CONSTRAINT; Schema: public; Owner: coach
--

ALTER TABLE ONLY public.weight_overrides
    ADD CONSTRAINT weight_overrides_pkey PRIMARY KEY (id);


--
-- Name: accounts_provider_uq; Type: INDEX; Schema: public; Owner: coach
--

CREATE UNIQUE INDEX accounts_provider_uq ON public.accounts USING btree (provider, provider_account_id);


--
-- Name: ai_analyses_user_date_uq; Type: INDEX; Schema: public; Owner: coach
--

CREATE UNIQUE INDEX ai_analyses_user_date_uq ON public.ai_analyses USING btree (user_id, session_date);


--
-- Name: ai_briefings_user_date_uq; Type: INDEX; Schema: public; Owner: coach
--

CREATE UNIQUE INDEX ai_briefings_user_date_uq ON public.ai_briefings USING btree (user_id, session_date);


--
-- Name: body_weight_user_date_uq; Type: INDEX; Schema: public; Owner: coach
--

CREATE UNIQUE INDEX body_weight_user_date_uq ON public.body_weight_log USING btree (user_id, date);


--
-- Name: gym_sessions_user_date_uq; Type: INDEX; Schema: public; Owner: coach
--

CREATE UNIQUE INDEX gym_sessions_user_date_uq ON public.gym_sessions USING btree (user_id, date);


--
-- Name: gym_sessions_user_idx; Type: INDEX; Schema: public; Owner: coach
--

CREATE INDEX gym_sessions_user_idx ON public.gym_sessions USING btree (user_id);


--
-- Name: mesocycles_user_idx; Type: INDEX; Schema: public; Owner: coach
--

CREATE INDEX mesocycles_user_idx ON public.mesocycles USING btree (user_id);


--
-- Name: prs_user_exercise_idx; Type: INDEX; Schema: public; Owner: coach
--

CREATE UNIQUE INDEX prs_user_exercise_idx ON public.personal_records USING btree (user_id, exercise_name);


--
-- Name: session_templates_user_idx; Type: INDEX; Schema: public; Owner: coach
--

CREATE INDEX session_templates_user_idx ON public.session_templates USING btree (user_id);


--
-- Name: weekly_summary_user_week_uq; Type: INDEX; Schema: public; Owner: coach
--

CREATE UNIQUE INDEX weekly_summary_user_week_uq ON public.weekly_ai_summaries USING btree (user_id, week_start);


--
-- Name: weight_overrides_user_exercise_uq; Type: INDEX; Schema: public; Owner: coach
--

CREATE UNIQUE INDEX weight_overrides_user_exercise_uq ON public.weight_overrides USING btree (user_id, exercise_name);


--
-- Name: accounts accounts_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: coach
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: ai_analyses ai_analyses_session_id_gym_sessions_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: coach
--

ALTER TABLE ONLY public.ai_analyses
    ADD CONSTRAINT ai_analyses_session_id_gym_sessions_id_fk FOREIGN KEY (session_id) REFERENCES public.gym_sessions(id) ON DELETE SET NULL;


--
-- Name: ai_analyses ai_analyses_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: coach
--

ALTER TABLE ONLY public.ai_analyses
    ADD CONSTRAINT ai_analyses_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: ai_briefings ai_briefings_session_id_gym_sessions_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: coach
--

ALTER TABLE ONLY public.ai_briefings
    ADD CONSTRAINT ai_briefings_session_id_gym_sessions_id_fk FOREIGN KEY (session_id) REFERENCES public.gym_sessions(id) ON DELETE SET NULL;


--
-- Name: ai_briefings ai_briefings_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: coach
--

ALTER TABLE ONLY public.ai_briefings
    ADD CONSTRAINT ai_briefings_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: auth_sessions auth_sessions_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: coach
--

ALTER TABLE ONLY public.auth_sessions
    ADD CONSTRAINT auth_sessions_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: body_weight_log body_weight_log_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: coach
--

ALTER TABLE ONLY public.body_weight_log
    ADD CONSTRAINT body_weight_log_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: exercise_catalog exercise_catalog_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: coach
--

ALTER TABLE ONLY public.exercise_catalog
    ADD CONSTRAINT exercise_catalog_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: gym_exercises gym_exercises_session_id_gym_sessions_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: coach
--

ALTER TABLE ONLY public.gym_exercises
    ADD CONSTRAINT gym_exercises_session_id_gym_sessions_id_fk FOREIGN KEY (session_id) REFERENCES public.gym_sessions(id) ON DELETE CASCADE;


--
-- Name: gym_sessions gym_sessions_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: coach
--

ALTER TABLE ONLY public.gym_sessions
    ADD CONSTRAINT gym_sessions_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: gym_sets gym_sets_exercise_id_gym_exercises_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: coach
--

ALTER TABLE ONLY public.gym_sets
    ADD CONSTRAINT gym_sets_exercise_id_gym_exercises_id_fk FOREIGN KEY (exercise_id) REFERENCES public.gym_exercises(id) ON DELETE CASCADE;


--
-- Name: mesocycles mesocycles_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: coach
--

ALTER TABLE ONLY public.mesocycles
    ADD CONSTRAINT mesocycles_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: personal_records personal_records_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: coach
--

ALTER TABLE ONLY public.personal_records
    ADD CONSTRAINT personal_records_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: session_templates session_templates_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: coach
--

ALTER TABLE ONLY public.session_templates
    ADD CONSTRAINT session_templates_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_settings user_settings_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: coach
--

ALTER TABLE ONLY public.user_settings
    ADD CONSTRAINT user_settings_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: weekly_ai_summaries weekly_ai_summaries_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: coach
--

ALTER TABLE ONLY public.weekly_ai_summaries
    ADD CONSTRAINT weekly_ai_summaries_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: weight_overrides weight_overrides_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: coach
--

ALTER TABLE ONLY public.weight_overrides
    ADD CONSTRAINT weight_overrides_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict JdoioBbiJklHmJCfVQOclUJTbeyyMhdXBo8c5VgUuJwT9KlZ2NobDucq7UQg1L8

